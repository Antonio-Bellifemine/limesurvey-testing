/******************
    User custom JS
    ---------------

   Put JS-functions for your template here.
   If possible use a closure, or add them to the general Template Object "Template"
*/
function setStartDate(questionId) {
    $(document).ready(function(){
        var today = new Date();
        var localDate = today.getFullYear() + '-' + 
                        String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                        String(today.getDate()).padStart(2, '0'); 
        localStorage.setItem('surveyStartDate', localDate); // Always update the date
        $('#answer' + questionId).val(localDate);
    });
}



$(document).ready(function() {
    var nextButtonForCheck = document.getElementById('ls-button-submit');
    var prevButtonForCheck = document.getElementById('ls-button-previous'); // Updated with correct ID

    // Clear session data if navigating back
    if (prevButtonForCheck) {
        prevButtonForCheck.addEventListener('click', function() {
            sessionStorage.removeItem('AlertStore');
        });
    }

    if (nextButtonForCheck) {
        nextButtonForCheck.addEventListener('click', function(event) {
            var sessionData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};
            console.log('sessionData count final', sessionData);
            console.log('sessionData count final', Object.keys(sessionData).length);
        
            let alertMessagesCheckboxes = [];
            let alertMessagesDropdowns = [];
            let alertMessagesRadios = [];
        
            if (Object.keys(sessionData).length !== 0) {
                Object.keys(sessionData).forEach(function(key) {
                    let value = sessionData[key]; 
                    
                    if (key.startsWith('select_')) {
                        // Add value only if it's not already in the array
                        if (!alertMessagesDropdowns.includes(value)) {
                            alertMessagesDropdowns.push(value);
                        }
                    } else if (key.startsWith('radio_')) {
                        // Add value only if it's not already in the array
                        if (!alertMessagesRadios.includes(value)) {
                            alertMessagesRadios.push(value);
                        }
                    } else {
                        // Add value only if it's not already in the array
                        if (!alertMessagesCheckboxes.includes(value)) {
                            alertMessagesCheckboxes.push(value);
                        }
                    }
                });
        
                let finalAlertMessage = '';
        
                if (alertMessagesDropdowns.length > 0) {
                    finalAlertMessage += "Please select a value from the dropdown for the following questions:\n" + alertMessagesDropdowns.join('\n') + "\n\n";
                }
        
                if (alertMessagesCheckboxes.length > 0) {
                    finalAlertMessage += "Please select at least one of the checkboxes and radio options for the following questions:\n" + alertMessagesCheckboxes.join('\n') + "\n\n";
                }

                if (alertMessagesRadios.length > 0) {
                    finalAlertMessage += "Please select a value for the following radio button questions:\n" + alertMessagesRadios.join('\n');
                }
        
                if (finalAlertMessage.length > 0) {
                    alert(finalAlertMessage);
        
                    event.preventDefault();
                }
            }
        });
    }   
});






function resetAnswers(ids) {
    
    console.log('Reset Answers inputs count  :', ids.length);                
    
    // Clear previous values if needed
    ids.forEach(function(id) {
        var element = $('#' + id);
        var elementType = element.attr('type');
        var tagName = element.prop('tagName').toLowerCase();
        var value = '';
        console.log('Reset Answers inputs count  :', id, elementType, tagName);                

        // Check if the element is visible before setting its value
        if (element.is(':visible')) {
            if (tagName === 'input') {
                if (elementType === 'checkbox' || elementType === 'radio') {
                    element.closest('.answer-item').find('input:hidden').val(value);
                    console.log('Reset Checkbox Value Set to ', value);
                }
            } else if (tagName === 'select') {
                if ($(this).attr('id') && !$(this).attr('id').includes('_date')) {
                    element.closest('.answer-item').find('input:hidden').val(value);
                    console.log('Reset Select DropDown Value Set to ', value);
                }
            }
        }
    });
    
    /*
    console.log('Reset Answers called for :', childID, questionCode, questionID);                

    // Clear previous values if needed
    $('input[id*="' + questionID + questionCode + '"]:checkbox, input[id*="' + questionID + questionCode + '"]:radio, select[id*="' + questionID + questionCode + '"]').each(function() {
        // Optional: Reset the input value if needed (for checkboxes/radios)
        if ($(this).is(':checkbox') || $(this).is(':radio')) {
            $(this).prop('checked', false); // Reset checkboxes/radios
            //$(this).closest('.answer-item').find('input:hidden').val('');
        } else {
            if ($(this).attr('id') && !$(this).attr('id').includes('_date')) {
                $(this).val(''); // Reset select inputs or other input types if necessary
                //$(this).closest('.answer-item').find('input:hidden').val('');
            }
        }
    });*/


    /*
    var checkboxAndSelectInputs = $('input[id*="' + questionID + questionCode + '"]:checkbox, input[id*="' + questionID + questionCode + '"]:radio, select[id*="' + questionID + questionCode + '"]')
    //var checkboxAndSelectInputs = $('input[id*="' + questionID  + questionCode + '"]:checkbox, select[id*="' + questionID + questionCode + '"]')
        .each(function() {
            var hiddenInputElement = $(this).closest('.answer-item').find('input:hidden');

            if ($(this).is(':checkbox') || $(this).is(':radio')) {
            //if ($(this).is(':checkbox')) {
                console.log('Checkbox input:', $(this).attr('id'), 'val:', $(this).prop('checked'));
                //hiddenInputElement.val('');
                console.log('Reset Answers Hidden input:', hiddenInputElement.attr('name'), 'val:', hiddenInputElement.val());                
            } else if ($(this).is('select')) {
                if ($(this).attr('id') && !$(this).attr('id').includes('_date')) {
                    console.log('Select input:', $(this).attr('id'), 'val:', $(this).val());
                    //hiddenInputElement.val('')
                    console.log('Reset Answers Hidden input:', hiddenInputElement.attr('name'), 'val:', hiddenInputElement.val());                
                }
            }
        });

    console.log('Reset Answers inputs count :', checkboxAndSelectInputs.length);                
    */
    
    
    /*
    // Get and log the IDs of the text inputs
    $('.answer-item', thisQuestion).find('input:hidden').each(function() {
        var textInputId = $(this).attr('id');
        console.log("Text input ID: " + textInputId);
        if (textInputId) {
            $(this).val('');  // Reset the value as per your original code
            saveAnswers($(this));
        }
    });
    
    // Get and log the IDs of hidden inputs within .answer-item, excluding those with '_textbox' or '_date'
    $('#' + childID + questionCode).find('input:checkbox, select').each(function() {
        var inputElement = $(this);
        var inputElementId = inputElement.attr('id');
        
        // Exclude '_textbox' or '_date'
        if (inputElementId && !inputElementId.includes('_textbox') && !inputElementId.includes('_date')) {
            
            if (inputElement.is(':checkbox')) {
                // Uncheck checkbox
                inputElement.prop('checked', false);
                inputElement.closest().find('input:hidden').val('');                
                console.log("Checkbox ID: ", inputElementId, 'Unchecked');
            } else if (inputElement.is('select')) {
                // Reset dropdown to no selection
                inputElement.val('');
                inputElement.closest().find('input:hidden').val('');                
                console.log("Select dropdown ID: ", inputElementId, 'Reset to no selection');
            }
        }
    });*/



}

function saveAnswersTest(element) {
    var id = element.attr('id');
    var name = element.attr('name');
    var value = element.val();
    //if (element.is(':radio')) {
    if (element.is(':radio') || element.is(':checkbox')) {
        // If it's a radio button, save the value of the checked radio
        value = element.is(':checked');
        //value = element.val();
    } else {
        // For other inputs, just save the current value
        value = element.val();
    }
    
    // Save the changes to session storage
    var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
    sessionData[id] = value;
    console.log('Saved id ', id, value);
    sessionStorage.setItem('LSStore', JSON.stringify(sessionData));    
    console.log('sessionData ', sessionData);
}

function saveAnswers(element) {
    var id = element.attr('id');
    var name = element.attr('name');
    var value = element.val();
    //if (element.is(':radio')) {
    if (element.is(':checkbox') || element.is(':radio')) {
        // If it's a radio button, save the value of the checked radio
        value = element.is(':checked');
        //value = element.val();
    } else {
        // For other inputs, just save the current value
        value = element.val();
    }
    
    if (name.endsWith('_radiogroup')) {
        value = element.val();
    }
    
    // Save the changes to session storage
    var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
    sessionData[id] = value;
    console.log('Saved id ', id, value);
    sessionStorage.setItem('LSStore', JSON.stringify(sessionData));    
    console.log('sessionData ', sessionData);
}

function loadAnswers(id) {

    // Retrieve session data
    var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};

    if (sessionData.hasOwnProperty(id)) {
        console.log('loadAnswers ID from sessionData found:', id, sessionData[id]);
        var element = $('#' + id);
        var elementType = element.attr('type');
        var tagName = element.prop('tagName').toLowerCase();
        var value = sessionData[id];

        // Check if the element is visible before setting its value
        if (element.is(':visible')) {
            if (tagName === 'input') {
                if (elementType === 'checkbox' || elementType === 'radio') {
                    //element.prop('checked', value).trigger('change');
                    element.prop('checked', value);
                    console.log(`${elementType.charAt(0).toUpperCase() + elementType.slice(1)} Checked State:`, element.prop('checked'), id);
                    console.log('Checkbox Checked State:', element.prop('checked'), id);
                    var checkboxValue = element.prop('checked') ? "1" : "0"; // Change value based on checkbox state
                    element.val(checkboxValue).trigger('change');
                    element.closest('.answer-item').find('input:hidden').val(checkboxValue);
                    console.log('Checkbox Value Set to ', checkboxValue);
                    
                } else {
                    element.val(value);
                    element.closest('.answer-item').find('input:hidden').val(value);
                }
                if (element.attr('name').endsWith('_radiogroup')){
                    element.val(value);
                    element.closest('.answer-item').find('input:hidden').val(value);
                }
            } else if (tagName === 'select' || tagName === 'textarea') {
                element.val(value);
                element.closest('.answer-item').find('input:hidden').val(value);
            }
        }

    } 
 
}

function modifyMedicationRoutine(previousQcode, currentQCode) {
      function medicationRows() {
        var inputVal = parseInt($('#answer' + previousQcode).val()); // Get the value from the specific input field
        if (isNaN(inputVal)) {
          // Hide all rows if the input is not a number or empty
          for (var i = 1; i <= 20; i++) {
            $('#javatbd' + currentQCode + 'SQ' + (i < 10 ? '00' + i : '0' + i)).hide();
          }
          return;
        }

        // Hide all rows initially
        for (var i = 1; i <= 20; i++) {
          $('#javatbd' + currentQCode + 'SQ' + (i < 10 ? '00' + i : '0' + i)).hide();
        }

        // Show rows up to the number entered in the input
        for (var i = 1; i <= inputVal && i <= 20; i++) {
          $('#javatbd' + currentQCode + 'SQ' + (i < 10 ? '00' + i : '0' + i)).show();
        }
      }
      
      $('#answer' + previousQcode).on('change keyup', medicationRows);
      
      medicationRows();
}

function toggleInfoBox() {
    const infoBox = document.querySelector('.info-box');
    infoBox.classList.toggle('collapsed');
}

function modifyDropdownFrequencySeverity(questionId) {
    var thisQuestion = $('#question' + questionId);

    let htmlString = '<select class="inserted-select form-control list-question-select">\
                                                    <option value="">Please choose...</option>\
                                                    <option value="1">Rare, Not severe</option>\
                                                    <option value="2">Rare, Severe</option>\
                                                    <option value="3">Occasional, Not Severe</option>\
                                                    <option value="4">Occasional, Severe</option>\
                                                    <option value="5">Frequent, Not severe</option>\
                                                    <option value="5">Frequent, Severe</option>\
                                                </select>';

	// Insert selects
	$('.answer-item', thisQuestion).append(htmlString);

	// Sync from dropdown to text input
	$('.inserted-select', thisQuestion).on('change', function() {
		var selectedValue = $(this).val();
		$(this).closest('.answer-item').find('input:text').val(selectedValue).trigger('change');
	});

	// Sync from text input to dropdown
	$('input:text', thisQuestion).each(function() {
		var thisCell = $(this).closest('.answer-item');
		var inputValue = $.trim($(this).val());
		$('select.inserted-select', thisCell).val(inputValue).trigger('change');
	});

	// Clean-up styles
	$('input:text', thisQuestion).css({
		'display': 'none'
	});
}

// Function to check if required fields are filled and update date input
function checkRequiredFields() {

    return false
    
    var allFilled = true;

    // Check regular inputs (excluding checkboxes)
    $('input[required]:not(:checkbox)').each(function() {
        //console.log('Id ', $(this).attr('id'));
        if (!$(this).val()) {
            if ($(this).hasClass('custom-date')) {
		        $(this).val('0000-00');
            } else {
                allFilled = false;
                $(this).css('border', '2px solid red');
            }
        } else {
            $(this).css('border', '');
        }
    });


    return allFilled;
}

function createNumericTextBoxforCell(element) {

    var textboxId = element.attr('id') + '_numerictextbox';

    var numericInput = $('<input type="text" class="custom-text" id="' + textboxId + '" name="' + element.attr('name') + '" min="0" />');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //var hiddenInput = $('<input type="hidden" value="N/A" />');
    var label = $('<label for="' + textboxId + '"></label>');    

    numericInput.css({
        'width': '100%' // Set fixed width
    });

    // Prevent non-numeric characters from being entered
    numericInput.on('keypress', function(event) {
        // Allow control keys (backspace, delete, arrows)
        if (event.which < 48 || event.which > 57) {
            event.preventDefault();
        }
    });
    
    element.after(label).after(numericInput).after(hiddenInput).remove();
    
    
    // Sync from radio buttons to text input
    $('input[type="text"][id='+textboxId+']').on('change', function() {
        //$(this).closest('.answer-item').find('input:text').val($(this).val()).trigger('change');
    
        var inputVal = $(this).val().trim(); // trim to remove any leading/trailing spaces
        var hiddenInput = $('input[type="hidden"][name='+textboxId+']');
    
        if (inputVal === '') {
            hiddenInput.val('N/A');
        } else {
            hiddenInput.val(inputVal);
        }

        //$(this).closest('.answer-item').find('input:hidden').val($(this).val());
        $(this).closest('.answer-item').find('input:hidden').val($(this).val());
        saveAnswers($(this));        
    });
    
	loadAnswers(textboxId);    
	
    return element;
    
}

function createTextBoxforCell(element) {

    var textboxId = element.attr('id') + '_textbox';
    //console.log(rowId); 
    var questionId = textboxId.match(/X(\d+)SQ/)[1];
    
    //console.log('questionId : ', questionId); 
    var thisQuestion = $('#question' + questionId);
    //console.log(thisQuestion);
    
    var checkbox = $('<input type="text" class="custom-text" id="' + textboxId + '" name="' + element.attr('name') + '" value=" " />');
    var hiddenInput = $('<input type="hidden" name="' + textboxId + '" value="N/A" />');
    var label = $('<label for="' + textboxId + '"></label>');    
    checkbox.css({
        'width': '100%', // Set fixed width
    });   
    
    element.after(label).after(checkbox).after(hiddenInput).remove();
    //element.after(checkbox).after(hiddenInput).remove();
    //element.after(checkbox).remove();
    
    
    // Sync from radio buttons to text input
    $('input[type="text"][id='+textboxId+']').on('change', function() {
        var inputVal = $(this).val().trim(); // trim to remove any leading/trailing spaces
        var hiddenInput = $('input[type="hidden"][name='+textboxId+']');
    
        if (inputVal === '') {
            hiddenInput.val('N/A');
        } else {
            hiddenInput.val(inputVal);
        }

        //$(this).closest('.answer-item').find('input:hidden').val($(this).val());
        saveAnswers($(this));
    });

	loadAnswers(textboxId);    
    
    return element;
    
}

function createCheckBoxforCell(element) {
    var checkboxId = element.attr('id') + '_checkbox';
    //console.log('checkboxId', checkboxId); 
    var questionId = checkboxId.match(/X(\d+)SQ/)[1];
    
    //console.log('questionId : ', questionId); 
    var thisQuestion = $('#question' + questionId);
    //console.log(thisQuestion);
    
    var checkbox = $('<input type="checkbox" class="custom-checkbox" id="' + checkboxId + '" name="' + element.attr('name') + '" value="0" />');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="" />');
    var label = $('<label for="' + checkboxId + '">&nbsp;Yes</label>');    
    element.after(label).after(checkbox).after(hiddenInput).remove();
    
    
    
    // Sync from radio buttons to text input
    $('input[type="checkbox"][id='+checkboxId+']').on('change', function() {
        var isChecked = $(this).is(':checked');
        var checkboxValue = isChecked ? "1" : "0"; // Change value based on checkbox state
        console.log('change cell check box', checkboxId, checkboxValue, $(this).closest('.answer-item').find('input:hidden').attr('name'));
        //hiddenInput.val(checkboxValue);
        $(this).val(checkboxValue);
        //var hiddenInputElement = $(this).closest('.answer-item').find('input:hidden');
        //hiddenInputElement.val(checkboxValue);
        //console.log('partical or full check :',hiddenInputElement.length,  hiddenInputElement.attr('name'), 'val : ', hiddenInputElement.val());


        //$(this).closest('.answer-item').find('input:text').val(checkboxValue).trigger('change');
        //$('input[type="hidden"][id="' + checkboxId + '"]').val(checkboxValue).trigger('change');
        $(this).closest('.answer-item').find('input:hidden').val(checkboxValue);
        saveAnswers($(this));
    });
    
	loadAnswers(checkboxId);
	
    return element;
}
function createRadioforYesNoDkCell(element) {
    var inputId = element.attr('id') + '_radio';
    var rowId = inputId.match(/answer(.*?)_/)[1];
    var questionId = rowId.match(/X(\d+)SQ/)[1];

    var thisQuestion = $('#question' + questionId);

    // Create radio buttons and hidden input
    var radioYes = $('<input type="radio" class="custom-radio" id="' + inputId + '_yes" name="radio_' + rowId + '" value="1" />');
    var radioNo = $('<input type="radio" class="custom-radio" id="' + inputId + '_no" name="radio_' + rowId + '" value="2" />');
    var radioDontKnow = $('<input type="radio" class="custom-radio" id="' + inputId + '_dontknow" name="radio_' + rowId + '" value="3" />');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="" />');

    var labelYes = $('<label for="' + inputId + '_yes" style="margin-right: 10px;">Yes</label>');
    var labelNo = $('<label for="' + inputId + '_no" style="margin-right: 10px;">No</label>');
    var labelDontKnow = $('<label for="' + inputId + '_dontknow">Don\'t know</label>');

    element.after(labelDontKnow).after(radioDontKnow)
           .after(labelNo).after(radioNo)
           .after(labelYes).after(radioYes)
           .after(hiddenInput).remove();

    // Sync from radio buttons to hidden input
    $('input[type="radio"][name=radio_' + rowId + ']').on('change', function() {
        console.log('change cell radio box', inputId, $(this).val());
        $(this).closest('.answer-item').find('input:hidden').val($(this).val()).trigger('change');
    });

    // Sync from hidden input to radio buttons
    var initialValue = hiddenInput.val();
    if (initialValue === "1") {
        radioYes.prop('checked', true);
    } else if (initialValue === "2") {
        radioNo.prop('checked', true);
    } else if (initialValue === "3") {
        radioDontKnow.prop('checked', true);
    }

    return element;
}
function createYesNoDontKnowRadioButtonsForCelltest(element) {
    var radioGroupId = element.attr('id') + '_radiogroup';
    
    // Create the radio button container
    var radioDev = $('<div id="radiodev_' + radioGroupId + '"></div>');
    var radioYes = $('<label><input type="radio" name="' + radioGroupId + '" value="1"> Yes</label>');
    var radioNo = $('<label><input type="radio" name="' + radioGroupId + '" value="2"> No</label>');
    var radioDontKnow = $('<label><input type="radio" name="' + radioGroupId + '" value="3"> Don\'t Know</label>');
    
    // Append the radio buttons to the container
    radioDev.append(radioYes).append(radioNo).append(radioDontKnow);

    // Create the hidden input element to store the selected value
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    
    // Replace the original element with the radio buttons and hidden input
    element.after(radioDev).after(hiddenInput).remove();

    // Event listener for radio button changes
    radioDev.find('input[type="radio"]').on('change', function() {
        var selectedValue = $(this).val();
        console.log('Radio button changed to ', selectedValue, $(this).attr('name'));
        $(this).closest('.answer-item').find('input:hidden').val(selectedValue).trigger('change');
        saveAnswers($(this));
    });

    // Initialize the radio buttons with existing answers
    loadAnswers('radiodev_' + radioGroupId);

    return element;
}

function createYesNoRadioButtonsForCelltest(element) {
    var radioGroupId = element.attr('id') + '_radiogroup';
    var hiddenId = element.attr('id') + '_hidden';
    var radioDev = $('<div id="radiodev_' + radioGroupId + '"></div>');
    var idYes = radioGroupId + '_yes';
    var idNo = radioGroupId + '_no';
    var radioYes = $('<label><input type="radio" name="'+ radioGroupId + '"id="'+ radioGroupId + '" value="1"> Yes</label>');
    var radioNo = $('<label><input type="radio" name="'+ radioGroupId + '"id="'+ radioGroupId + '" value="2"> No</label>');
    
    radioDev.append(radioYes).append(radioNo);

    // Create the hidden input element
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '"id="' + hiddenId + '" value="N/A" />');
    
    // Replace the original element with the radio buttons and hidden input
    element.after(radioDev).after(hiddenInput).remove();

    // Event listener for radio button change
    radioDev.find('input[type="radio"]').on('change', function() {
        console.log('Tag of `this` is:', $(this).prop('tagName'));
        var selectedValue = $(this).val();
        console.log('Radio button changed to ', selectedValue, $(this).attr('name'), $(this).attr('id'));
        console.log('closest hidden:', $(this).closest('.answer-item').find('input:hidden')[0]);
        $(this).closest('.answer-item').find('input:hidden').attr('value',selectedValue).trigger('change');
        console.log('closest hidden after VALUE UPDATE:', $(this).closest('.answer-item').find('input:hidden')[0]);
        saveAnswers($(this));
    });

    // Initialize the radio buttons with existing answers
    loadAnswers('radiodev_' + radioGroupId);

    return element;
}


function createRadioforYesNoCell(element) {
    var inputId = element.attr('id') + '_radio';
    var rowId = inputId.match(/answer(.*?)_/)[1];
    var questionId = rowId.match(/X(\d+)SQ/)[1];

    var thisQuestion = $('#question' + questionId);

    // Create radio buttons and hidden input
    var radioYes = $('<input type="radio" class="custom-radio" id="' + inputId + '_yes" name="radio_' + rowId + '" value="1" />');
    var radioNo = $('<input type="radio" class="custom-radio" id="' + inputId + '_no" name="radio_' + rowId + '" value="2" />');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="" />');

    var labelYes = $('<label for="' + inputId + '_yes" style="margin-right: 10px;">Yes</label>');
    var labelNo = $('<label for="' + inputId + '_no" style="margin-right: 10px;">No</label>');

    element.after(labelNo).after(radioNo)
           .after(labelYes).after(radioYes)
           .after(hiddenInput).remove();

    // Sync from radio buttons to hidden input
    $('input[type="radio"][name=radio_' + rowId + ']').on('change', function() {
        console.log('change cell radio box', inputId, $(this).val());
        $(this).closest('.answer-item').find('input:hidden').val($(this).val()).trigger('change');
        saveAnswers($(this));
    });

    // Sync from hidden input to radio buttons
    var initialValue = hiddenInput.val();
    if (initialValue === "1") {
        radioYes.prop('checked', true);
    } else if (initialValue === "2") {
        radioNo.prop('checked', true);
    }
	loadAnswers(inputId);

    return element;
}

function createRadioforCell(element) {
    var inputId = element.attr('id') + '_radio';
    var rowId = inputId.match(/answer(.*?)_/)[1];
    //console.log('rowId', rowId); 
    var questionId = rowId.match(/X(\d+)SQ/)[1];
    
    //console.log(questionId); 
    var thisQuestion = $('#question' + questionId);
    //console.log(thisQuestion);

    
    var radio = $('<input type="radio" class="custom-radio" id="' + inputId + '" name="radio_' + rowId + '" value="1" />');
    //var radio = $('<input type="radio" class="custom-radio" id="' + inputId + '" name="' + element.attr('name') + '" value="1" />');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="" />');
    var label = $('<label for="' + inputId + '"></label>');    
    element.after(label).after(radio).after(hiddenInput).remove();

    /*
    $('.answer-item', thisQuestion).each(function(index) {
        var $inputText = $(this).find('input[type="hidden"]');
        var inputId = $inputText.val();
        console.log(inputId);
    });*/

    // Sync from radio buttons to text input
    $('input[type="radio"][id='+inputId+']').on('change', function() {
      
        var isChecked = $(this).is(':checked');
        var checkboxValue = isChecked ? "1" : "0"; // Change value based on checkbox state
        console.log('change cell radio box', inputId, checkboxValue);
        $(this).closest('.answer-item').find('input:hidden').val(checkboxValue).trigger('change');
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        var idPrefix = $(this).attr('id').split('_AO')[0];
        for (let id in sessionData) {
            if (id.startsWith(idPrefix)) {
                delete sessionData[id]; // Delete the key if it starts with "blah"
            }
        }        
        console.log('sessionData', sessionData);
        sessionStorage.setItem('LSStore', JSON.stringify(sessionData));    
        saveAnswers($(this));
    });
    
	loadAnswers(inputId);
    
    /*    
    // Sync from text input to checkbox
    $('input:hidden', thisQuestion).each(function() {
        var thisCell = $(this).closest('.answer-item');
        var inputValue = $.trim($(this).val());
        var isChecked = (inputValue === "1"); // Assume "1" means checked, change this condition if needed
        $('.inserted-radio', thisCell).prop('checked', isChecked).trigger('change');
    });*/
    
    return element;
}

function createDateYrFieldforCell(element){
    var cusdateId = element.attr('id') + '_dateyr';
    var container = $('<div>');
    
    //var dateInput = $('<input type="month" class="custom-month-picker" id="' + cusdateId + '" name="' + cusdateId + '" />');
    //var dateInput = $('<div id="customMonthYearPicker"><select id="monthPicker">'+Array.from({length:12},(_,i)=>'<option value="'+(i+1).toString().padStart(2,0)+'">'+new Date(2000,i).toLocaleString(navigator.language,{month:'long'})+'</option>').join('')+'</select><select id="yearPicker">'+Array.from({length:21},(_,i)=>'<option value="'+(new Date().getFullYear()-10+i)+'">'+(new Date().getFullYear()-10+i)+'</option>').join('')+'</select></div>').appendTo('body');
    // Set min and max attributes to restrict selection
    //var dateInput = $('<div id="customMonthYearPicker"><select id="monthPicker">'+Array.from({length:12},(_,i)=>'<option value="'+(i+1).toString().padStart(2,0)+'">'+new Date(2000,i).toLocaleString(navigator.language,{month:'long'})+'</option>').join('')+'</select>&nbsp;<select id="yearPicker">'+Array.from({length:21},(_,i)=>'<option value="'+(new Date().getFullYear()-10+i)+'">'+(new Date().getFullYear()-10+i)+'</option>').join('')+'</select></div>').appendTo('body');

    var endYear = new Date().getFullYear(); // end year
    //var startYear = 1920; // start year
    
    var currentYear = new Date().getFullYear(); // Get current year
    var startYear = currentYear - 18; // Subtract 18 years
    
    console.log(startYear); // Output the start year

    var dateInput = $('<div id="customMonthYearPicker_' + cusdateId +'"><select id="yearPicker_' + cusdateId + '"><option value="">YYYY</option>'+Array.from({length:endYear - startYear + 1},(_,i)=>'<option value="'+(endYear-i)+'">'+(endYear-i)+'</option>').join('')+'</select></div>').appendTo('body');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //dateInput.attr('value', 'YYYY-MM'); // Example minimum date
    //dateInput.attr('min', '0000-00'); // Example minimum date
    //dateInput.attr('max', '0000-00'); // Example maximum date
    
    //var startYear = 1900;
    //var endYear = new Date().getFullYear();

    // Function to format the date
    dateInput.css({
        'width': '100%', // Set fixed width
    });     
    container.append(dateInput);
    element.after(container).after(hiddenInput).remove();

    $('#customMonthYearPicker_' + cusdateId + ' select').on('change', function() {
        var year = $('#yearPicker_' + cusdateId).val();
        $(this).closest('.answer-item').find('input:hidden').val(year).trigger('change');
    });

    return element;
}

function isValidMonthYear(monthYear) {
    // Regular expression to check mm-yyyy format
    var regex = /^(0[1-9]|1[0-2])-(\d{4})$/;
    return regex.test(monthYear);
}

function convertToDateObject(monthYear) {
    if (!isValidMonthYear(monthYear)) {
        console.error('Invalid date format. Please use mm-yyyy.');
        return null;
    }
    
    var parts = monthYear.split('-');
    var month = parseInt(parts[0], 10); // mm
    var year = parseInt(parts[1], 10); // yyyy

    // Create Date object with the first day of the month
    return new Date(year, month - 1, 1); // Months are 0-indexed in JavaScript Date
}

function saveDateforStartEnd(baseCusdateId, ColId, selectedValue) {
    let dates = JSON.parse(sessionStorage.getItem(baseCusdateId)) || {};
    dates[ColId] = selectedValue;
    sessionStorage.setItem(baseCusdateId, JSON.stringify(dates));
}

function compareStartEndDates(baseCusdateId) {
    let dates = JSON.parse(sessionStorage.getItem(baseCusdateId));
    
    if (dates) {
        // Extract the dates
        let colIds = Object.keys(dates);
        
        // Ensure there are exactly two dates
        if (colIds.length === 2) {
            
            let date1 = parseMonthYear(dates[colIds[0]]);
            let date2 = parseMonthYear(dates[colIds[1]]);
            console.log(date1, date2, 'colIds : ', colIds, dates[colIds[0]], dates[colIds[1]], 'baseCusdateId : ', baseCusdateId);

            // Check if both dates are valid
            if (!isNaN(date1.getTime()) && !isNaN(date2.getTime())) {
                // Perform the comparison
                if (date1 > date2) {
                    console.log(`Alert: ${date1.toISOString().split('T')[0]} is not less than ${date2.toISOString().split('T')[0]}`);
                    return true;
                } else {
                    console.log(`${date1.toISOString().split('T')[0]} is less than ${date2.toISOString().split('T')[0]}`);
                    return false;
                }
            } else {
                console.log('One or both of the dates are invalid.');
            }
        } else {
            console.log('There should be exactly two dates for comparison.');
        }
    } else {
        console.log('No dates found for', baseCusdateId);
    }
}

function parseMonthYear(monthYear) {
    // Extract month and year
    let [month, year] = monthYear.split('-').map(Number);
    // Return a Date object representing the first day of the given month and year
    return new Date(year, month - 1, 1);
}

function createDateFieldforCell(element){
    var cusdateId = element.attr('id') + '_date';
    var container = $('<div>');
    var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
    
    //var dateInput = $('<input type="month" class="custom-month-picker" id="' + cusdateId + '" name="' + cusdateId + '" />');
    //var dateInput = $('<div id="customMonthYearPicker"><select id="monthPicker">'+Array.from({length:12},(_,i)=>'<option value="'+(i+1).toString().padStart(2,0)+'">'+new Date(2000,i).toLocaleString(navigator.language,{month:'long'})+'</option>').join('')+'</select><select id="yearPicker">'+Array.from({length:21},(_,i)=>'<option value="'+(new Date().getFullYear()-10+i)+'">'+(new Date().getFullYear()-10+i)+'</option>').join('')+'</select></div>').appendTo('body');
    // Set min and max attributes to restrict selection
    //var dateInput = $('<div id="customMonthYearPicker"><select id="monthPicker">'+Array.from({length:12},(_,i)=>'<option value="'+(i+1).toString().padStart(2,0)+'">'+new Date(2000,i).toLocaleString(navigator.language,{month:'long'})+'</option>').join('')+'</select>&nbsp;<select id="yearPicker">'+Array.from({length:21},(_,i)=>'<option value="'+(new Date().getFullYear()-10+i)+'">'+(new Date().getFullYear()-10+i)+'</option>').join('')+'</select></div>').appendTo('body');

    var endYear = new Date().getFullYear(); // end year
    //var startYear = 1920; // start year
    
    var currentYear = new Date().getFullYear(); // Get current year
    var startYear = currentYear - 18; // Subtract 18 years
    
    var dateInput = $('<div id="customMonthYearPicker_' + cusdateId +'"><select id="monthPicker_' + cusdateId + '"><option value="">Month</option>'+Array.from({length:12},(_,i)=>'<option value="'+(i+1).toString().padStart(2,0)+'">'+new Date(2000,i).toLocaleString(navigator.language,{month:'long'})+'</option>').join('')+'</select>&nbsp;<select id="yearPicker_' + cusdateId + '"><option value="">YYYY</option>'+Array.from({length:endYear - startYear + 1},(_,i)=>'<option value="'+(endYear-i)+'">'+(endYear-i)+'</option>').join('')+'</select></div>').appendTo('body');
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //dateInput.attr('value', 'YYYY-MM'); // Example minimum date
    //dateInput.attr('min', '0000-00'); // Example minimum date
    //dateInput.attr('max', '0000-00'); // Example maximum date
    
    //var startYear = 1900;
    //var endYear = new Date().getFullYear();
    
    // Populate year dropdown
    var yearSelect = $('#yearPicker_' + cusdateId);

    // Populate month dropdown
    var monthSelect = $('#monthPicker_' + cusdateId);
    //console.log('Date sessionData ', sessionData);

    var selectedValue = '';
    var savedmonthValue = '';
    var savedyearValue = '';
    if (sessionData.hasOwnProperty(yearSelect.attr('id'))) {
        console.log('loads data for ', yearSelect.attr('id'), sessionData[yearSelect.attr('id')]);
        savedyearValue = sessionData[yearSelect.attr('id')];
        yearSelect.val(savedyearValue);
    }
    
    if (sessionData.hasOwnProperty(monthSelect.attr('id'))) {
        console.log('loads data for ', monthSelect.attr('id'), sessionData[monthSelect.attr('id')]);
        savedmonthValue = sessionData[monthSelect.attr('id')];
        monthSelect.val(savedmonthValue);
    }
    
    if (savedmonthValue && savedyearValue) {
        // Both monthSelect and year are present
        selectedValue = savedmonthValue + '-' + savedyearValue;
    } else if (savedmonthValue) {
        // Only monthSelect is present
        selectedValue = savedmonthValue;
    } else if (savedyearValue) {
        // Only year is present
        selectedValue = savedyearValue;
    }
        
    if (selectedValue) {
        hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="'+ selectedValue + '" />');
    } 
    var baseCusdateId = cusdateId.split('_')[0];
    var ColId = cusdateId.split('_')[1];
    saveDateforStartEnd(baseCusdateId, ColId, "N/A");
        
    // Update months when year changes
    $('#yearPicker_' + cusdateId).change(function() {
        //console.log('inputId ', cusdateId);
        updateMonths();
    });
  
    function updateMonths() {
        var year = $('#yearPicker_' + cusdateId).val();
        var monthSelect = $('#monthPicker_' + cusdateId);
        var selectedValue = monthSelect.val();
        console.log('month selectedValue' , selectedValue);
        monthSelect.empty(); // Clear existing options
        
        var currentYear = new Date().getFullYear();
        var currentMonth = new Date().getMonth() + 1; // Adding 1 because months are zero-based
        
        var monthsInYear = (year == currentYear) ? currentMonth : 12; // Show only valid months if current year
        $('<option value=0"">Month</option>').appendTo(monthSelect);
        for (var i = 1; i <= monthsInYear; i++) {
          var monthName = new Date(year, i - 1).toLocaleString(navigator.language, { month: 'long' });
          $('<option>', { value: i.toString().padStart(2, '0'), text: monthName }).appendTo(monthSelect);
        }
        if (selectedValue <= monthsInYear) {
            monthSelect.val(selectedValue);
        }
    }
 
    // Function to format the date
    dateInput.css({
        'width': '100%', // Set fixed width
    });     
    container.append(dateInput);
    element.after(container).after(hiddenInput).remove();
    // Create the label element
    //var label = $('<label>').text('');
    var label = $('<label>').attr('id', cusdateId).text('');

    
    // Add the label before the container element
    label.insertBefore(container);
    
    $('#customMonthYearPicker_' + cusdateId + ' select').on('change', function() {
        var yrElemt = $('#yearPicker_' + cusdateId);
        var monthElemt = $('#monthPicker_' + cusdateId);
        var year = yrElemt.val();
        var monthSelect = monthElemt.val();

        // Save the changes to session storage
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        sessionData[yrElemt.attr('id')] = year;
        sessionData[monthElemt.attr('id')] = monthSelect;
        console.log('Saved id ', yrElemt.attr('id'), year, monthElemt.attr('id'), monthSelect);
        sessionStorage.setItem('LSStore', JSON.stringify(sessionData)); 
        
        //var selectedValue = monthSelect + '-' + year;
        var selectedValue = '';
        // Check if monthSelect and year are not null or empty
        if (monthSelect && year) {
            // Both monthSelect and year are present
            selectedValue = monthSelect + '-' + year;
        } else if (monthSelect) {
            // Only monthSelect is present
            selectedValue = monthSelect;
        } else if (year) {
            // Only year is present
            selectedValue = year;
        }

    
        //label.text('Selected Date: ' + monthSelect + '-' + year);
        // Define the base substring, prefix, and suffix
        var baseCusdateId = cusdateId.split('_')[0];
        var ColId = cusdateId.split('_')[1];
        var prefix = 'customMonthYearPicker_answer';
        var suffix = '_date';
        saveDateforStartEnd(baseCusdateId, ColId, selectedValue);
        console.log('ColId: ', ColId, 'cusdateId : ', cusdateId, 'Date picker value : ', selectedValue, ' for ', $(this).attr('id'));
        if (compareStartEndDates(baseCusdateId)) {
        // If the date is invalid, show an error message in red
            label.text('Start date must be less than end date');
            label.css('color', 'red');            
        } else {
            $('label[id*="' + baseCusdateId + '"]').each(function() {
                $(this).text('');
                $(this).css('color', ''); // Reset color to default
            });
            $(this).closest('.answer-item').find('input:hidden').val(selectedValue).trigger('change');
            selectedValue = '';
            //label.text('');
            //label.css('color', '');              
        }
    });

    return element;
}


function createDropdownForCell(element, modType='', frequencyOptions='') {
    var dropdownId = element.attr('id') + '_dropdown';
    
    var dropdowndev = $('<div id="selectdev_' + dropdownId +'"></div>');
    var selectElement = $('<select  name="' + dropdownId + '" id="select_' + dropdownId + '"><option value="">Please Choose...</option></select>');
    
    dropdowndev.append(selectElement);
    
    var optionTexts = [];

    if (modType === "mild") {
        optionTexts = ['Never', 'Mild', 'Moderate', 'Severe']; 
    } 
    else if (modType === "severe") {
        optionTexts = ['Mild', 'Moderate', 'Severe']; 
    }  
    else if (modType === "rare-notsevere") {
        optionTexts = ['Rare, Not Severe', 'Rare, Severe','Occasional, Not Severe','Occasional, Severe','Frequent, Not Severe', 'Frequent, Severe'];
    }
    else if (modType === "routine") {
        optionTexts = ['several times a day', 'once a day', 'several times a week', 'occasionally', 'at certain times of the year']; 
    }
    else if (modType === "route") {
        optionTexts = ['oral (liquid)', 'oral (chewable)', 'oral (pill)', 'inhaled; intranasal', 'transdermal', 'injectable (e.g. a shot)', 'intravenous (IV)', 'rectal', 'enteral (feeding tube)'];
    }
    else if (modType === "allergy") {
        optionTexts = ['allergy', 'life-threatening allergy', 'intolerance/sensitivity'];
    }    
    else if (modType === "never") {
        optionTexts = ['Never', 'Once', 'Rarely', 'Sometimes', 'often', 'Daily', 'More than once daily'];
    }
    else if (modType === "never-rarely-always") {
        optionTexts = ['never', 'rarely', 'sometimes', 'often', 'daily', 'always'];
    }
    else if (modType === "never-always") { 
        optionTexts = ['never', 'rarely', 'sometimes', 'often', 'always']; 
    } 
    else if (modType === "rarely-daily") { 
        optionTexts = ['never', 'rarely', 'sometimes', 'daily']; 
    }     
    else if (modType === "rarely-always") { 
        optionTexts = ['rarely', 'sometimes', 'often', 'always']; 
    } 
    else if (modType === "never-once-rare-freq") { 
        optionTexts = ['never', 'once', 'rarely', 'occasionally', 'frequently']; 
    } 
    else if (modType === "rarely-sometimes-often-constantly") { 
        optionTexts = ['rarely', 'sometimes', 'often', 'constantly']; 
    } 
    else if (modType === "never-rarely-sometimes-often-constantly") { 
        optionTexts = ['never','rarely', 'sometimes', 'often', 'constantly']; 
    } 
    else if (modType === "rare-freq") {
        optionTexts = ['Never', 'Rare', 'Occasional', 'Frequent'];
    }
    else if (modType === "never-rare-freq") {
        optionTexts = ['Never', 'Rare', 'Occasional', 'Frequent'];
    }
    else if (modType === "rare-severe") {
        optionTexts = ['Never', 'Rare, Not Severe', 'Rare, Severe','Occasional, Not Severe','Occasional, Severe','Frequent, Not Severe', 'Frequent, Severe'];
    }
    else if (modType === "numbers10") {
        optionTexts = ['1','2','3','4','5','6','7','8','9','10 or More']; 
    }   
    else if (modType === "numbers20") {
        optionTexts = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20 or More'];
    }
    else if (modType === "numbers20WithNever") {
        optionTexts = ['never' ,'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20 or More'];
    } 
    else if (modType === "numbersFractional") {
        optionTexts = ['<1/4', '1/4', '1/2', '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '>10']; 
    }  
    else if (modType === "supplement") {
        optionTexts = ['occasionally', 'several times a week', 'once a day', 'several times a day'];
    } 
    else if (modType.includes(";")) {
        optionTexts = modType.split(";");
        //console.log('optionTexts', optionTexts);
    }    
    
    optionTexts.forEach(function (optionText) {
        var option = $('<option value="' + optionText.toLowerCase() + '">' + optionText + '</option>');
        selectElement.append(option);
    });
    
    selectElement.css({
        'width': '100%' // Set fixed width
    });
    
    // Create the hidden input element
    var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="N/A" />');
    //var hiddenInput = $('<input type="hidden" name="' + element.attr('name') + '" value="" />');
    
    element.after(dropdowndev).after(hiddenInput).remove();

    selectElement.on('change', function() {
        var selectedValue = $(this).val();
        console.log('cell dropdown changed to ', selectedValue, $(this).attr('id'));
        //$(this).closest('.answer-item').find('input:text').val(selectedValue).trigger('change');
        //$('input[type="hidden"][id="' + $(this).attr('id') + '"]').val(selectedValue).trigger('change');
        $(this).closest('.answer-item').find('input:hidden').val(selectedValue).trigger('change');
        saveAnswers($(this));
    });

	loadAnswers('select_'+dropdownId);

    return element;
}

function modifyDropdownHowOften(questionId, modType="default") {
    var thisQuestion = $('#question' + questionId);

    let htmlString = getDropDownOptions(modType)

	// Insert selects
	$('.answer-item', thisQuestion).append(htmlString);

    // Set default value to 'N/A' for all text inputs
    $('.answer-item', thisQuestion).find('input:text').val('N/A');
    

	$('.answer-item', thisQuestion).each(function() {
        var inputText = $(this).find('input[type="text"]');
        // Create the hidden input element
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        if (sessionData.hasOwnProperty(inputText.attr('id'))) {
            var value = sessionData[inputText.attr('id')];
            console.log('load answers modifyDropdownHowOften id : ', inputText.attr('id'), inputText.attr('name'), value);
    		$('select.inserted-select', $(this)).val(value);
            inputText.val(value);
        }
	});
	
    /*
	$('.answer-item', thisQuestion).each(function() {
        // Create the hidden input element
        var $inputText = $(this).find('input[type="text"]');
        $(htmlString).css({
            'width': '100%' // Set fixed width
        });
        const hiddenInput = $('<input type="hidden" name="' + $inputText.attr('name')  + '" value="N/A" />');
        $(this).after($(htmlString)).after(hiddenInput).remove();
	});*/
	

	// Sync from dropdown and checkboxes to text input
	$('.inserted-select, .inserted-checkboxes', thisQuestion).on('change', function() {
        var selectedValue = $(this).val();
        console.log('modifyDropdownHowOften ', $(this).closest('.answer-item').find('input:text').attr('name'), $(this).closest('.answer-item').find('input:text').attr('id'));
        $(this).closest('.answer-item').find('input:text').val(selectedValue).trigger('change');
        saveAnswers($(this).closest('.answer-item').find('input:text'));
    });



    /*
	// Sync from text input to dropdown
	$('input:text', thisQuestion).each(function() {
		var thisCell = $(this).closest('.answer-item');
		console.log('thisCell', thisCell.attr('id'));
		var inputValue = $.trim($(this).val());
		$('select.inserted-select', thisCell).val(inputValue).trigger('change');
	});*/

    //loadAnswers($(this));
	// Clean-up styles
	$('input:text', thisQuestion).css({
		'display': 'none'
	});
}

function getDropDownOptions(modType="default") {
    
    let htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
            <option value="more than once daily">More Than Once Daily</option>\
        </select>';

    if (modType === "never") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
            <option value="more than once daily">More Than Once Daily</option>\
        </select>';
    }
    if (modType === "never-dontknow") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
            <option value="more than once daily">More Than Once Daily</option>\
            <option value="don\'t know">Don\'t know</option>\
        </select>';
    }
    else if (modType === "once") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="once">Once</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
            <option value="more than once daily">More Than Once Daily</option>\
        </select>';
    }
    if (modType === "never-once") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="once">Once</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
            <option value="more than once daily">More Than Once Daily</option>\
        </select>';
    }
    else if (modType === "daily") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="once">Once</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
        </select>';
    }
    else if (modType === "severity-only") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="mild">Mild</option>\
            <option value="moderate">Moderate</option>\
            <option value="severe">Severe</option>\
        </select>';
    }
    else if (modType === "never-daily") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="once">Once</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
        </select>';
    }
    else if (modType === "how_often_always") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="almost always or always">Almost Always or Always</option>\
        </select>';
    }
    else if (modType === "never-daily-2") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
        </select>';
    }
    else if (modType === "never-once-rare-freq") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="once">Once</option>\
            <option value="rarely">Rarely</option>\
            <option value="occasionally">Occasionally</option>\
            <option value="frequently">Frequently</option>\
        </select>';
    }
    else if (modType === "never-once-rare-freq-na") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="once">Once</option>\
            <option value="rarely">Rarely</option>\
            <option value="occasionally">Occasionally</option>\
            <option value="frequently">Frequently</option>\
            <option value="not applicable">Not Applicable</option>\
        </select>';
    }
    else if (modType === "how-often-annually") { 
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="daily">Daily</option>\
            <option value="weekly">Weekly</option>\
            <option value="monthly">Monthly</option>\
            <option value="quarterly">Quarterly</option>\
            <option value="bi-annually">Bi-Annually</option>\
            <option value="annually">Annually</option>\
        </select>';
    }
    else if (modType === "sometimes") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
        </select>';
    }
    else if (modType === "radioTrimester") {
        htmlString = '<div class="inserted-checkboxes list-question-checkboxes">\
            <label><input type="checkbox" name="checkbox-option" value="Trimester 1">Trimester 1</label>\
            <label><input type="checkbox" name="checkbox-option" value="Trimester 2">Trimester 2</label>\
            <label><input type="checkbox" name="checkbox-option" value="Trimester 3">Trimester 3</label>\
        </div>';
    }
    else if (modType === "constantly") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="constantly">Constantly</option>\
        </select>';
    }
    //constantly with extra option of daily
    else if (modType === "constantly-daily") { 
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
            <option value="constantly">Constantly</option>\
        </select>'; 
    } 
    //never; rarely; sometimes; often; very often; constantly		
    else if (modType === "never-constantly") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="never">Never</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="very often">Very Often</option>\
            <option value="constantly">Constantly</option>\
        </select>';    
    }
     //rarely; sometimes; often; very often; constantly
    else if (modType === "rarely-constantly") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="very often">Very Often</option>\
            <option value="constantly">Constantly</option>\
        </select>';    
    }
    else if (modType === "rarely-daily2") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">Rarely</option>\
            <option value="sometimes">Sometimes</option>\
            <option value="often">Often</option>\
            <option value="daily">Daily</option>\
        </select>';    
    }
    //rare, not severe; rare, severe; occasional, not severe; occasional, severe; frequent, not severe; frequent, severe
    else if (modType === "rare-severe-frequency") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rare, not severe">Rare, Not Severe</option>\
            <option value="rare, severe">Rare, Severe</option>\
            <option value="occasional, not severe">Occasional, Not Severe</option>\
            <option value="occasional, severe">Occasional, Severe</option>\
            <option value="frequent, not severe">Frequent, Not Severe</option>\
            <option value="frequent, severe">Frequent, Severe</option>\
        </select>';    
    } 
    else if (modType === "side-of-body") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="unable">unable</option>\
            <option value="left side">left side</option>\
            <option value="right side">right side</option>\
            <option value="both sides">both sides</option>\
            <option value="don\'t know">don\'t know</option>\
        </select>';    
    }
        else if (modType === "devices-daily") {
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">\
            <option value="" >Please choose...</option>\
            <option value="rarely">rarely</option>\
            <option value="sometimes">sometimes</option>\
            <option value="occasionally throughout the day">occasionallythroughout the day</option>\
            <option value="often throughout the day">often throughout the day</option>\
            <option value="constantly throughout the day">constantly throughout the day</options>\
        </select>';    
    }
    //never; every couple of years;at least annually; twice a year; quarterly; more than quarterly
    else if (modType === "never-quarterly") {
        const frequencyOptions = "never; every couple of years; at least annually; twice a year; quarterly; more than quarterly";
        
        // Split the string into an array using the delimiter "; "
        const optionsArray = frequencyOptions.split(";");
        
        // Construct the HTML string for the select options
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">';
        htmlString += '<option value="" >Please choose...</option>';
        
        // Loop through the options and add each option to the HTML string
        for (const option of optionsArray) {
            htmlString += `<option value="${option.trim()}">${option.trim()}</option>`;
        }
        htmlString += '</select>';
    } 
    else if (modType === "age-0-18") {
        const frequencyOptions = "0; 1; 2; 3; 4; 5; 6; 7; 8; 9;10;11;12;13;14;15;16;17;18";
        
        // Split the string into an array using the delimiter "; "
        const optionsArray = frequencyOptions.split(";");
        
        // Construct the HTML string for the select options
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">';
        htmlString += '<option value="" >Please choose...</option>';
        
        // Loop through the options and add each option to the HTML string
        for (const option of optionsArray) {
            htmlString += `<option value="${option.trim()}">${option.trim()}</option>`;
        }
        htmlString += '</select>';
    } else if (modType === "child-milestone") {
        const frequencyOptions = "not achieved; skipped milestone; 0-3 months; 4-6 months; 7-9 months; 10-12 months; 13-15 months; 16-18 months; 19-24 months; between 2 and 3 years; between 3 and 4 years; more than 4 years old";

        // Split the string into an array using the delimiter "; "
        const optionsArray = frequencyOptions.split(";");
        
        // Construct the HTML string for the select options
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">';
        htmlString += '<option value="" >Please choose...</option>';
        
        // Loop through the options and add each option to the HTML string
        for (const option of optionsArray) {
            htmlString += `<option value="${option.trim()}">${option.trim()}</option>`;
        }
        htmlString += '</select>';        
    } else if (modType === "ageOptions") {
        const frequencyOptions = "has not mastered; 1 yr; 2 yr; 3 yr; 4 yr; 5 yr; 6 yr; 7 yr; 8 yr; 9 yr; 10 yr; 11 yr; 12 yr; 13 yr; 14 yr; 15 yr; 16 yr; 17 yr";

        // Split the string into an array using the delimiter "; "
        const optionsArray = frequencyOptions.split(";");
        
        // Construct the HTML string for the select options
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">';
        htmlString += '<option value="" >Please choose...</option>';
        
        // Loop through the options and add each option to the HTML string
        for (const option of optionsArray) {
            htmlString += `<option value="${option.trim()}">${option.trim()}</option>`;
        }
        htmlString += '</select>';           
        
        
    }  else if (modType.includes(";")) {
        const optionsArray = modType.split(";");
        //console.log('optionTexts', optionTexts);
        // Construct the HTML string for the select options
        htmlString = '<select style="max-width: 100%" class="inserted-select form-control list-question-select">';
        htmlString += '<option value="" >Please choose...</option>';
        
        // Loop through the options and add each option to the HTML string
        for (const option of optionsArray) {
            htmlString += `<option value="${option.trim()}">${option.trim()}</option>`;
        }
        htmlString += '</select>';  
    }  
    
    return htmlString;
}

function modifyDropdownHowOftenWithDefault(questionId, modType="default") {
    var thisQuestion = $('#question' + questionId);

    let htmlString = getDropDownOptions(modType)


    $('.answer-item', thisQuestion).each(function() {
        // Create the hidden input element
        var $inputText = $(this).closest('.answer-item').find('input:text');
        console.log($inputText.attr('name'));
        const hiddenInput = $('<input type="hidden" name="' + $inputText.attr('name')  + '" value="N/A" />');
        $(this).after($(htmlString)).after(hiddenInput).remove();
    });
    
	// Sync from dropdown and checkboxes to text input
	$('.inserted-select, .inserted-checkboxes', thisQuestion).on('change', function() {
        var selectedValue = $(this).val();
        $(this).closest('.answer-item').find('input:text').val(selectedValue).trigger('change');
    });


	// Sync from text input to dropdown
	$('input:text', thisQuestion).each(function() {
		var thisCell = $(this).closest('.answer-item');
		var inputValue = $.trim($(this).val());
		$('select.inserted-select', thisCell).val(inputValue).trigger('change');
	});

	// Clean-up styles
	$('input:text', thisQuestion).css({
		'display': 'none'
	});

}


function modifyCheckListAllforMulColsWithNone(questionId, GlobalId, NoneId) {
    var thisQuestion = $('#question' + questionId);

    
    $('.answer-item', thisQuestion).each(function(index) {
        var rowNumber = index + 1;

        var $inputText = $(this).find('input[type="text"]');
        var inputId = $inputText.attr('id');
        var colId = inputId.split('_').pop();

    
        /*
        if (inputId && inputId.includes(`${questionId}`) && inputId.includes(GlobalId)) {
            console.log('First Row:', rowNumber, 'Input ID:', inputId, 'colId : ', colId);
        }

        if (inputId && inputId.includes(`${questionId}`) && inputId.includes(NoneId)) {
            console.log('Last Row:', rowNumber, 'Input ID:', inputId, 'colId : ', colId);
        }*/
        
        if (inputId && inputId.includes(`${questionId}`) && inputId.includes(GlobalId)) {

            var checkBoxValue = $('.answer-item', thisQuestion).first().find('input[type="text"]').val();
            if (checkBoxValue === "") {
                $('.answer-item', thisQuestion).first().find('input[type="text"]').val("0");
            }


            var checkboxGroup = $(`
                <div class="checkbox-group">
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_yes_${questionId}" value="1" class="inserted-checkbox" data-column="3"> Yes</label>
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_no_${questionId}" value="2" class="inserted-checkbox" data-column="3"> No</label>
                    <label><input type="checkbox" name="checkbox_dontknow_${questionId}_${colId}" value="3" class="inserted-checkbox" data-column="3"> Don't know</label>
                </div>
            `);

            $(this).find('input[type="text"]').after(checkboxGroup).css('display', 'none');

            checkboxGroup.on('change', 'input[type="checkbox"]', function() {
                var isChecked = $(this).prop('checked');
                var checkboxName = $(this).attr('name');
                var groupId = $(this).attr('id');

                if (isChecked) {
                    var NoneCheckBoxElement = $(`input[name^="checkbox_none_${questionId}_${colId}"]`);
                    NoneCheckBoxElement.each(function() {
                        var name = $(this).attr('name');
                        var id = $(this).attr('id');
                        
                        // Log the name, id, and checked status of the current input element
                        console.log('Name:', name, ' | ID:', id, ' | Checked:', $(this).prop("checked"));
                        $(this).prop('checked', false)
                    });                    
                    $(this).closest('.checkbox-group').find(`input[type="checkbox"][name$="${colId}"]`).not(this).prop('checked', false);
                }

                if (checkboxName.includes("dontknow") && isChecked) {
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="3"][name$="' + colId + '"]').prop('checked', true);
                        //$(this).find('.radio-group .inserted-radio[value="3"]').prop('checked', true);
                        $(this).find('input[type="text"][name$="' + colId + '"]').val("3").change();
                    });
                } else if (checkboxName.includes("dontknow") && !isChecked) {
                    $('.answer-item', thisQuestion).first().find('input[type="text"][name$="' + colId + '"]').val("0").change();
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="3"][name$="' + colId + '"]').prop('checked', false).change();
                        //$(this).find('.radio-group .inserted-radio').prop('checked', false).change();
                        $(this).find('input[type="text"][name$="' + colId + '"]').val("3").change();
                    });
                }
            });

            if (checkBoxValue === "3") {
                var dontKnowCheckbox = $(this).find('input[type="checkbox"][name="checkbox_dontknow"]');
                dontKnowCheckbox.prop('checked', true);
                dontKnowCheckbox.change();
            }
        
        } 
        else if (inputId && inputId.includes(`${questionId}`) && inputId.includes(NoneId)) {
            $(this).click(function() {
                if ($(this).prop('checked')) {
                    $('.answer-item', thisQuestion).last().find('input[type="text"][name*="' + GlobalId + '"][name*="' + colId + '"]').prop('checked', false);
                }
            });
            
            var checkBoxValue = $('.answer-item', thisQuestion).last().find('input[type="text"]').val();
            if (checkBoxValue === "") {
                $('.answer-item', thisQuestion).last().find('input[type="text"]').val("0");
            }

            var checkboxGroup = $(`
                <div class="checkbox-group">
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_yes_${questionId}_${colId}" value="1" class="inserted-checkbox" data-column="3"> Yes</label>
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_no_${questionId}_${colId}" value="2" class="inserted-checkbox" data-column="3"> No</label>
                    <label style="margin-right:50px;"><input type="checkbox" name="checkbox_none_${questionId}_${colId}" value="4" class="inserted-checkbox" data-column="3"> None of the above</label>
                </div>
            `);

            $(this).find('input[type="text"]').after(checkboxGroup).css('display', 'none');

            checkboxGroup.on('change', 'input[type="checkbox"]', function() {
                var isChecked = $(this).prop('checked');
                var checkboxName = $(this).attr('name');
                var groupId = $(this).attr('id');

                if (isChecked) {
                    var NoneCheckBoxElement = $(`input[name^="checkbox_dontknow_${questionId}_${colId}"]`);
                    NoneCheckBoxElement.each(function() {
                        var name = $(this).attr('name');
                        var id = $(this).attr('id');
                        
                        // Log the name, id, and checked status of the current input element
                        console.log('Name:', name, ' | ID:', id, ' | Checked:', $(this).prop("checked"));
                        $(this).prop('checked', false)
                    });                      
                    $(this).closest('.checkbox-group').find(`input[type="checkbox"][name$="${colId}"]`).not(this).prop('checked', false);
                }


                if (checkboxName.includes("no") && isChecked) {
                    $('.answer-item', thisQuestion).first().find('input[type="text"][name$="' + colId + '"]').val("0").change();
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="2"][name$="' + colId + '"]').prop('checked', true);
                        //$(this).find('.radio-group .inserted-radio[value="2"]').prop('checked', true);
                        $(this).find('input[type="text"][name$="' + colId + '"]').val("2").change();
                    });
                } else if (checkboxName.includes("no") && !isChecked) {
                    $('.answer-item', thisQuestion).last().find('input[type="text"][name$="' + colId + '"]').val("0").change();
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="2"][name$="' + colId + '"]').prop('checked', false).change();
                        //$(this).find('.radio-group .inserted-radio').prop('checked', false).change();
                        $(this).find('input[type="text"][name$="' + colId + '"]').val("2").change();
                    });
                }
            });

            if (checkBoxValue === "4") {
                var checkbox_no = $(this).find('input[type="checkbox"][name="checkbox_no"]');
                checkbox_no.prop('checked', true);
                checkbox_no.change();
            }
        
        }
        else {
            
            $(this).click(function() {
                console.log('Input id clicked ', inputId);
                $(`input[name^="checkbox_dontknow_${questionId}_${colId}"]`).prop('checked', false);
                $(`input[name^="checkbox_none_${questionId}_${colId}"]`).prop('checked', false);
            });
            
            var inputValue = $inputText.val();
            $inputText.css('display', 'none');

            var radioGroup = $(`
                <div class="radio-group">
                    <label style="margin-right: 10px"><input type="radio" name="radio_${questionId}_${index}_${colId}" value="1" class="inserted-radio"> Yes</label>
                    <label style="margin-right: 10px"><input type="radio" name="radio_${questionId}_${index}_${colId}" value="2" class="inserted-radio"> No</label>
                    <label><input type="radio" name="radio_${questionId}_${index}_${colId}" value="3" class="inserted-radio"> Don't know</label>
                </div>
            `);

            radioGroup.find('input[value="' + inputValue + '"]').prop('checked', true);
            $inputText.after(radioGroup);

            radioGroup.on('change', 'input[type="radio"]', function() {
                $inputText.val($(this).val()).change();
            });
            //console.log('ID:', inputId, ' | Checked:', $(this).prop("checked"));
            //$(this).trigger('change');
        }
       
        if (inputId && inputId.includes(`${questionId}`) && !inputId.includes(GlobalId) && !inputId.includes(NoneId)) {
            radioGroup.on('change', 'input[type="radio"]', function() {
                $inputText.val($(this).val()).change();
                console.log('Value changed ', $(this).val());

                if ($(this).val() !== "3") {
                    var checkboxes = $('.answer-item', thisQuestion).find('.checkbox-group input[type="checkbox"][name*="' + colId + '"]');

                    checkboxes.prop('checked', false)
                    
                    //$('.answer-item', thisQuestion).first().find('.checkbox-group input[type="checkbox"]').prop('checked', false);
                    //$('.answer-item', thisQuestion).first().find('input[type="text"]').val("0");
                }
            });
        }
        
    });
}

function modifyCheckListAllforMulCols(questionId) {
    var thisQuestion = $('#question' + questionId);

    $('.answer-item', thisQuestion).each(function(index) {
        var rowNumber = index + 1;

        var $inputText = $(this).find('input[type="text"]');
        var inputId = $inputText.attr('id');
        var colId = inputId.split('_').pop();

        if (inputId && inputId.includes(`${questionId}`) && inputId.includes("SQ001")) {
            console.log('First Row:', rowNumber, 'Input ID:', inputId, 'colId : ', colId);
            $(this).find('input[type="text"][name$="' + colId + '"]').val("N/A").change();
        }

        if (inputId && inputId.includes(`${questionId}`) && inputId.includes("SQ001")) {
            var checkBoxValue = $('.answer-item', thisQuestion).first().find('input[type="text"]').val();
            if (checkBoxValue === "") {
                $('.answer-item', thisQuestion).first().find('input[type="text"]').val("0");
            }
            else{
                $('.answer-item', thisQuestion).first().find('input[type="text"]').val(checkBoxValue);
            }

            var checkboxGroup = $(`
                <div class="checkbox-group">
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_yes_${questionId}_${colId}" value="2" class="inserted-checkbox" data-column="3"> Yes</label>
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_no_${questionId}_${colId}" value="2" class="inserted-checkbox" data-column="3"> No</label>
                    <label><input type="checkbox" name="checkbox_dontknow_${questionId}_${colId}" value="3" class="inserted-checkbox" data-column="3"> Don't know</label>
                </div>
            `);

            $(this).find('input[type="text"]').after(checkboxGroup).css('display', 'none');

            checkboxGroup.on('change', 'input[type="checkbox"]', function() {
                var isChecked = $(this).prop('checked');
                var checkboxName = $(this).attr('name');
                var groupId = $(this).attr('id');

                if (isChecked) {
                    $(this).closest('.checkbox-group').find(`input[type="checkbox"][name$="${colId}"]`).not(this).prop('checked', false);
                }

                if (checkboxName.includes("dontknow") && isChecked) {
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="3"][name$="' + colId + '"]').prop('checked', true);
                        //$(this).find('.radio-group .inserted-radio[value="3"]').prop('checked', true);
                        $(this).find('input[type="text"][name$="' + colId + '"]').val("3").change();
                    });
                } else if (checkboxName.includes("dontknow") && !isChecked) {
                    $('.answer-item', thisQuestion).first().find('input[type="text"][name$="' + colId + '"]').val("0").change();
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="3"][name$="' + colId + '"]').prop('checked', false).change();
                        //$(this).find('.radio-group .inserted-radio').prop('checked', false).change();
                        $(this).find('input[type="text"][name$="' + colId + '"]').val("3").change();
                    });
                }
            });

            if (checkBoxValue === "3") {
                var dontKnowCheckbox = $(this).find('input[type="checkbox"][name="checkbox_dontknow"]');
                dontKnowCheckbox.prop('checked', true);
                dontKnowCheckbox.change();
            }
        } else {
            
            $(this).click(function() {
                console.log('Input id clicked ', inputId);
                $(`input[name^="checkbox_dontknow_${questionId}_SQ001"]`).prop('checked', false);
            });
            
            var inputValue = $inputText.val();
            $inputText.css('display', 'none');

            var radioGroup = $(`
                <div class="radio-group">
                    <label style="margin-right: 10px"><input type="radio" name="radio_${questionId}_${index}_${colId}" value="1" class="inserted-radio"> Yes</label>
                    <label style="margin-right: 10px"><input type="radio" name="radio_${questionId}_${index}_${colId}" value="2" class="inserted-radio"> No</label>
                    <label><input type="radio" name="radio_${questionId}_${index}_${colId}" value="3" class="inserted-radio"> Don't know</label>
                </div>
            `);

            radioGroup.find('input[value="' + inputValue + '"]').prop('checked', true);
            $inputText.after(radioGroup);

            radioGroup.on('change', 'input[type="radio"]', function() {
                $inputText.val($(this).val()).change();
            });
        }

        if (inputId && inputId.includes(`${questionId}`) && !inputId.includes("SQ001")) {
            radioGroup.on('change', 'input[type="radio"]', function() {
                $inputText.val($(this).val()).change();

                if ($(this).val() !== "3") {
                    var colId = $(this).attr('name').split('_').pop();
                    var checkboxes = $('.answer-item', thisQuestion).find('.checkbox-group input[type="checkbox"][name*="' + colId + '"]');

                    checkboxes.prop('checked', false)
                    //$('.answer-item', thisQuestion).first().find('.checkbox-group input[type="checkbox"]').prop('checked', false);
                    //$('.answer-item', thisQuestion).first().find('input[type="text"]').val("0");
                }
            });
        }
    });
}


function modifyCheckListAll(questionId) {
    var thisQuestion = $('#question' + questionId);
    //console.log('thisQuestion', thisQuestion);
    $('.answer-item', thisQuestion).each(function(index) {

        // Handle special checkbox case
        if (index === 0) {
            let checkBoxValue = $('.answer-item', thisQuestion).first().find('input[type="text"]').val();
            if (checkBoxValue === "") {
                $('.answer-item', thisQuestion).first().find('input[type="text"]').val("0")
            }else{
                $('.answer-item', thisQuestion).first().find('input[type="text"]').val(checkBoxValue)
            }

            var checkboxGroup = $(`
                <div class="checkbox-group">
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_yes_${questionId}" value="1" class="inserted-checkbox" data-column="3"> Yes</label>
                    <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_no_${questionId}" value="2" class="inserted-checkbox" data-column="3"> No</label>
                    <label><input type="checkbox" name="checkbox_dontknow_${questionId}_${index}" value="3" class="inserted-checkbox" data-column="3"> Don't know</label>
                </div>
            `);
            
            /*
            var checkboxGroup = $('<div class="checkbox-group">\
                <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_yes_' + questionId + '" value="2" class="inserted-checkbox" data-column="3"> Yes</label>\
                <label style="margin-right:10px; visibility: hidden;"><input type="checkbox" name="checkbox_no_' + questionId + '" value="2" class="inserted-checkbox" data-column="3"> No</label>\
                <label><input type="checkbox" name="checkbox_dontknow_${questionId}_${colId}" value="3" class="inserted-checkbox" data-column="3"> Don't know</label>
            </div>'); */

            // Insert the checkbox group after the text input
            $(this).find('input[type="text"]').after(checkboxGroup).css('display', 'none');

            // Add a change event listener to the checkbox at index 0
            checkboxGroup.on('change', 'input[type="checkbox"]', function() {
                let isChecked = $(this).prop('checked');
                let checkboxName = $(this).attr('name');
            
                // Uncheck other checkboxes in the group if this checkbox is checked
                if (isChecked) {
                    $(this).closest('.checkbox-group').find('input[type="checkbox"]').not(this).prop('checked', false);
                }
                
                if (checkboxName.includes("dontknow") && isChecked) {
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio[value="3"]').prop('checked', true);
                        $(this).find('input[type="text"]').val("3").change();
                    });
                } 
                else if (checkboxName.includes("dontknow") && !isChecked) {
                    $('.answer-item', thisQuestion).first().find('input[type="text"]').val("0").change();
                    // New code to clear all radio buttons
                    $('.answer-item', thisQuestion).each(function() {
                        $(this).find('.radio-group .inserted-radio').prop('checked', false).change();
                        $(this).find('input[type="text"]').val("");
                    });
                } 
            });
 
            if (checkBoxValue === "3") {
                let dontKnowCheckbox = $(this).find('input[type="checkbox"][name="checkbox_dontknow"]');
                dontKnowCheckbox.prop('checked', true);
                dontKnowCheckbox.change(); // Trigger the change event on the "Don't know" checkbox
            }
          
        } else {
            // Regular case for other indexes: radio group
            var $inputText = $(this).find('input[type="text"]');
            var inputValue = $inputText.val(); // store the initial value
            $inputText.css('display', 'none')

            // Create the radio group
            var radioGroup = $('<div class="radio-group">\
                <label style="margin-right: 10px"><input type="radio" name="radio_' + questionId + '_' + index + '" value="1" class="inserted-radio"> Yes</label>\
                <label style="margin-right: 10px"><input type="radio" name="radio_' + questionId + '_' + index + '" value="2" class="inserted-radio"> No</label>\
                <label><input type="radio" name="radio_' + questionId + '_' + index + '" value="3" class="inserted-radio"> Don\'t know</label>\
            </div>');

            // Set the initial value based on the hidden text input
            radioGroup.find('input[value="' + inputValue + '"]').prop('checked', true);

            // Insert the radio group after the text input
            $inputText.after(radioGroup);

            // Add a change event listener to the radio group
            radioGroup.on('change', 'input[type="radio"]', function() {
                // Update the hidden text input with the selected value
                $inputText.val($(this).val()).change();
            });
        }

        if (index > 0) {
            // Add a change event listener to the radio group
            radioGroup.on('change', 'input[type="radio"]', function() {
                // Update the hidden text input with the selected value
                $inputText.val($(this).val()).change();

                // If the selected radio button is not "Don't know", deselect the checkbox at index 0
                if ($(this).val() !== "3") {
                    $('.answer-item', thisQuestion).first().find('.checkbox-group input[type="checkbox"]').prop('checked', false);
                    $('.answer-item', thisQuestion).first().find('input[type="text"]').val("0");
                }
            });
        }
    });
}

function modifyRadioYesNoAll(questionId) {
    var thisQuestion = $('#question' + questionId);
    console.log('thisQuestion', thisQuestion);
    
    $('.answer-item', thisQuestion).each(function(index) {
        var $inputText = $(this).find('input[type="text"]');
        var inputValue = $inputText.val(); // Store the initial value
        $inputText.css('display', 'none');

        // Create the radio group with Yes and No options
        var radioGroup = $('<div class="radio-group">\
            <label style="margin-right: 10px"><input type="radio" name="radio_' + questionId + '_' + index + '" value="1" class="inserted-radio"> Yes</label>\
            <label><input type="radio" name="radio_' + questionId + '_' + index + '" value="2" class="inserted-radio"> No</label>\
        </div>');

        // Set the initial value based on the hidden text input
        radioGroup.find('input[value="' + inputValue + '"]').prop('checked', true);

        // Insert the radio group after the text input
        $inputText.after(radioGroup);

        // Add a change event listener to the radio group
        radioGroup.on('change', 'input[type="radio"]', function() {
            // Update the hidden text input with the selected value
            $inputText.val($(this).val()).change();
        });
    });
}
function modifyYesNoNoneAll(questionId) {
    var thisQuestion = $('#question' + questionId);
    console.log('thisQuestion', thisQuestion);
    $('.answer-item', thisQuestion).each(function(index) {

        // Handle special checkbox case for the first row
        if (index === 0) {
            let checkBoxValue = $('.answer-item', thisQuestion).first().find('input[type="text"]').val();
            if (checkBoxValue === "") {
                $('.answer-item', thisQuestion).first().find('input[type="text"]').val("0")
            }

            var checkboxGroup = $('<div class="checkbox-group">\
                <label><input type="checkbox" name="checkbox_no_' + questionId + '" value="3" class="inserted-checkbox" data-column="3"> None</label>\
            </div>');

            // Insert the checkbox group after the text input
            $(this).find('input[type="text"]').after(checkboxGroup).css('display', 'none');

            // Add a change event listener to the checkbox at index 0
            checkboxGroup.on('change', 'input[type="checkbox"]', function() {
                let isChecked = $(this).prop('checked');
                let checkboxName = $(this).attr('name');

                // Uncheck other checkboxes in the group if this checkbox is checked
                if (isChecked) {
                    $(this).closest('.checkbox-group').find('input[type="checkbox"]').not(this).prop('checked', false);
                }

                // If the "No" checkbox is checked in the first row, set all other rows to "No"
                if (checkboxName.includes("checkbox_no") && isChecked) {
                    $('.answer-item', thisQuestion).each(function(index) {
                        if (index > 0) {
                            $(this).find('.inserted-radio[value="2"]').prop('checked', true).change();
                            $(this).find('input[type="text"]').val("2").change();
                        }
                    });
                } 
                // If the "No" checkbox is unchecked, clear all radio buttons in other rows
                else if (checkboxName.includes("checkbox_no") && !isChecked) {
                    $('.answer-item', thisQuestion).each(function(index) {
                        if (index > 0) {
                            $(this).find('.inserted-radio').prop('checked', false).change();
                            $(this).find('input[type="text"]').val("").change();
                        }
                    });
                }
            });

        } else {
            // Regular case for other indexes: radio group with Yes and No only
            var $inputText = $(this).find('input[type="text"]');
            var inputValue = $inputText.val(); // store the initial value
            $inputText.css('display', 'none')

            // Create the radio group with Yes and No options
            var radioGroup = $('<div class="radio-group">\
                <label style="margin-right: 10px"><input type="radio" name="radio_' + questionId + '_' + index + '" value="1" class="inserted-radio"> Yes</label>\
                <label><input type="radio" name="radio_' + questionId + '_' + index + '" value="2" class="inserted-radio"> No</label>\
            </div>');

            // Set the initial value based on the hidden text input
            radioGroup.find('input[value="' + inputValue + '"]').prop('checked', true);

            // Insert the radio group after the text input
            $inputText.after(radioGroup);

            // Add a change event listener to the radio group
            radioGroup.on('change', 'input[type="radio"]', function() {
                // Update the hidden text input with the selected value
                $inputText.val($(this).val()).change();

                // If the selected radio button is "Yes", deselect the "None" checkbox at index 0
                if ($(this).val() === "1") {
                    $('.answer-item', thisQuestion).first().find('input[name="checkbox_no_' + questionId + '"]').prop('checked', false);
                }
            });
        }
    });
}




// Function to add special "none of the above" functionality to the last checkbox of a question
function modifyLastCheckboxBehaviour(questionID) {
    // Select the question element using the provided ID
    var thisQuestion = $('#question' + questionID);
    var lastCheckbox = $('.answer-item input[type="checkbox"]', thisQuestion).last();

    // Function to handle checkbox changes
    function handleCheckboxChange() {
        // Select all other checkboxes except for the lastCheckbox
        var otherCheckboxes = $('.answer-item input[type="checkbox"]', thisQuestion).not(lastCheckbox);

        // Check if it's checked
        if (lastCheckbox.prop('checked')) {
            // Disable, uncheck all other checkboxes, and clear the value of the following hidden inputs
            otherCheckboxes.prop({'checked': false, 'disabled': true}).nextAll('input:hidden:eq(0)').attr('value', '');
            otherCheckboxes.change();
        } else {
            // Enable all other checkboxes if this one is unchecked
            otherCheckboxes.prop('disabled', false).nextAll('input:hidden:eq(0)').attr('value', '');
        }
    }

    // Attach the change event listener to the last checkbox
    lastCheckbox.on('change', handleCheckboxChange);

    // Trigger the change event manually if the checkbox is already checked on page load
    if (lastCheckbox.prop('checked')) {
        lastCheckbox.trigger('change');
    }

    
}

// Function to modify checkbox behavior for last and second last checkboxes
function modifyLastAndSecondLastCheckboxBehaviour(questionID) {
    // Select the question element using the provided ID
    var thisQuestion = $('#question' + questionID);
    var checkboxes = $('.answer-item input[type="checkbox"]', thisQuestion);
    var lastCheckbox = checkboxes.last();
    var secondLastCheckbox = checkboxes.eq(checkboxes.length - 2);

    // Function to handle checkbox changes for both last and second last checkboxes
    function handleCheckboxChange() {
        var isChecked = $(this).prop('checked');
        var otherCheckboxes = $('.answer-item input[type="checkbox"]', thisQuestion).not(lastCheckbox).not(secondLastCheckbox);

        // Disable all other checkboxes except the clicked checkbox based on whether it's the last or second last
        if ($(this).is(lastCheckbox)) {
            //otherCheckboxes.prop({'checked': false, 'disabled': true}).nextAll('input:hidden:eq(0)').attr('value', '');
            //otherCheckboxes.change();            
            checkboxes.not(lastCheckbox).prop({'checked': false, 'disabled': isChecked});
            if (isChecked) {
                otherCheckboxes.prop({'checked': false, 'disabled': true}).nextAll('input:hidden:eq(0)').attr('value', '');
                otherCheckboxes.change();
            }
        } else if ($(this).is(secondLastCheckbox)) {
            checkboxes.not(secondLastCheckbox).prop({'checked': false, 'disabled': isChecked});
            if (isChecked) {
                otherCheckboxes.prop({'checked': false, 'disabled': true}).nextAll('input:hidden:eq(0)').attr('value', '');
                otherCheckboxes.change();
            }
        }
    }

    // Attach the change event listeners to both last and second last checkboxes
    lastCheckbox.on('change', handleCheckboxChange);
    secondLastCheckbox.on('change', handleCheckboxChange);

    // Trigger the change event manually if either checkbox is already checked on page load
    if (lastCheckbox.prop('checked')) {
        lastCheckbox.trigger('change');
    }
    if (secondLastCheckbox.prop('checked')) {
        secondLastCheckbox.trigger('change');
    }
}

// Function to add "Yes" checkboxes to a specified question
function modifyQuestionWithSingleCheckboxes(questionID) {
    var thisQuestion = $('#question' + questionID);

    // Insert checkboxes if they haven't been added yet
    if (!thisQuestion.find(".inserted-checkbox").length) {
        var checkboxTemplate = '<div class="list-question-select">' +
            '<span class="clickable-span">' +
            '<input value="1" class="inserted-checkbox" type="checkbox" id="checkbox_' + questionID + '_INDEX" name="checkbox_' + questionID + '" /> &nbsp;Yes</span>' +
            '</div>';
        $('.answer-item', thisQuestion).addClass('with-select').each(function(index) {
            var updatedTemplate = checkboxTemplate.replace('INDEX', index + 1);
            $(this).append(updatedTemplate);
        });

    }
    
    // Set default value to 'N/A' for all text inputs
    $('.answer-item', thisQuestion).find('input:text').val('N/A');

    // Sync from checkbox to text input
    $('.inserted-checkbox', thisQuestion).on('change', function() {
        var isChecked = $(this).is(':checked');
        var checkboxValue = isChecked ? "1" : "0"; // Change value based on checkbox state
        $(this).closest('.answer-item').find('input:text').val(checkboxValue).trigger('change');
        saveAnswers($(this).closest('.answer-item').find('input:text'));
    });
    
    // Sync from text input to checkbox
    $('input:text', thisQuestion).each(function() {
        var inputText = $(this).find('input[type="text"]');
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        if (sessionData.hasOwnProperty(inputText.attr('id'))) {
            var value = sessionData[inputText.attr('id')];
            console.log('load answers modifyQuestionWithSingleCheckboxes id : ', inputText.attr('id'), inputText.attr('name'), value);
    		$('select.inserted-select', $(this)).val(value);
            inputText.val(value);
        }
        /*
        var thisCell = $(this).closest('.answer-item');
        var inputValue = $.trim($(this).val());
        var isChecked = (inputValue === "1"); // Assume "1" means checked, change this condition if needed
        $('.inserted-checkbox', thisCell).prop('checked', isChecked).trigger('change');*/
    });

    // Apply styles to the inserted checkboxes
    $('input.inserted-checkbox', thisQuestion).addClass('big-checkbox');

}

function conditionalCheckBoxAllQuestionIgnoreCols(questionID, parentID, childID, IgnroeList) {

    let thisQuestion = $('#question'+questionID);

    //console.log(thisQuestion, parentID, childID);
    
    // Hide all elements with IDs that start with a specific pattern initially
    $('[id^=' + childID + 'SQ]').hide();
    $('[id^=' + childID + 'AO]').hide();
    
    // Add a change event listener to all input element whose id conatins parentID
    $('input[id*="' + parentID + '"]').change(function() {
        // Do something with each element
        //console.log('change', $(this).attr('name'), 'value', $(this).prop('checked'));
        var name = $(this).attr('name');
        // Get the label associated with the element
        // Check if the label is disabled
        var ignIndex = endsWithAny(name, IgnroeList);
        //console.log('name ', name, ignIndex);
        var sqIndex = name.indexOf('SQ');
		var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
        //console.log('conditional debug : ', questionCode, ' ', sqIndex);

        // Toggle the visibility of the corresponding element based on the checkbox value
		if ($(this).prop('checked') && ignIndex) {
            //$('#' + childID + questionCode).find('input:hidden').val('');		    
            if ($('#' + childID + questionCode).length) $('#' + childID + questionCode).show();
		} else {
            //$('#' + childID + questionCode).find('input:hidden').val('N/A');		    
            if ($('#' + childID + questionCode).length) $('#' + childID + questionCode).hide();
		}
		
		if ($(this).prop('checked') && !ignIndex) {
	        $('[id^=' + childID + 'SQ]').hide();
		}
		
        // Count the number of checked with checked
        var count = $('input[id*="' + parentID + '"]').filter(function() {
            //console.log('name : ', $(this).attr('name'), 'checked : ', $(this).prop('checked'))
            var ignIndex = endsWithAny($(this).attr('name'), IgnroeList);
            if ($(this).prop('checked') === true && ignIndex) {
                var sqIndex = $(this).attr('name').indexOf('SQ');
        		var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
                if ($('#' + childID + questionCode).length && ignIndex) {
                    return $(this)
                }
            }; // Checks if the checkbox is checked and valid child index
        }).length; // Counts the filtered checkboxes
        console.log('count', count); // Logs the count to the console
    
        // Show thisQuestion if count is greater than 0
        if (count > 0) {
            thisQuestion.show();
        } else {
            thisQuestion.hide();
        }
    
    });
    
    // Select all elements where the id contains "patrentID" add trigger for change
    $('input[id*="' + parentID + '"]').each(function() {
        // Do something with each element
        $(this).trigger('change');
        //console.log('added trigger', $(this).attr('id'));
    });
    
    // Function to check if the name ends with any of the values in ignoreparentCols
    function endsWithAny(name, ignoreparentCols) {
        for (var i = 0; i < ignoreparentCols.length; i++) {
            if (name.endsWith(ignoreparentCols[i])) {
                return false;
            }
        }
        return true;
    }

}

function conditionalChildAndGrandChildQuestion(questionID, parentID, childID, condchildID) {

    let thisQuestion = $('#question'+questionID);
    console.log('All QIDs : ', questionID, parentID, childID, condchildID);

    
    // Add a change event listener to all input element whose id conatins parentID
    $('input[id*="' + parentID + '"], input[id*="' + condchildID + '"]').on('change', function() {


        console.log('change', questionID, $(this).attr('name'), 'value', $(this).val(), 'Id', $(this).attr('id'), $(this).is(':checked'));
        $('[id*=' + questionID + '] input[type="radio"], [id*=' + childID + '] input[type="checkbox"]').prop('checked', false);
        $('[id*=' + questionID + '] select').prop('selectedIndex', 0);
        // Clear text areas
        $('[id*=' + questionID + '] textarea').val('');        
    
    });

    // Select all elements where the id contains "condChildID" add trigger for change
    $('input[id*="' + condchildID + '"]').each(function() {
        // Do something with each element
        $(this).trigger('change');
    });
    
    // Select all elements where the id contains "patrentID" add trigger for change
    $('input[id*="' + parentID + '"]').each(function() {
        // Do something with each element
        $(this).trigger('change');
    });

}
function checkNullValuesTier2Radio(idPrefix) {
    // Select all radio buttons that match the idPrefix
    var radios = document.querySelectorAll("input[type='radio'][id^='" + idPrefix + "']");
    var isChecked = false;
    
    if (radios.length > 0) {
        // Check if any radio button in the group is selected
        radios.forEach(function(radio) {
            if (radio.checked) {
                isChecked = true; // If any radio button is checked, set this to true
            }
        });
        console.log("Radio buttons group", radios);

        var sessionData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};

        if (!isChecked) {
            // If no radio button is checked, mark the form as invalid and store alert
            isFormValid = false;

            var questionText = radios[0].closest('tr').querySelector('th') ? radios[0].closest('tr').querySelector('th').textContent.trim() : "Question";

            sessionData[idPrefix] = questionText;
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionData));
            console.log("Radio button check failed for:", idPrefix);
        } else {
            // If at least one radio button is checked, clean up the stored alert
            console.log("At least one radio button checked for:", idPrefix);
            
            var cleanedIdPrefix = idPrefix.replace(/_AO\d+_radio$/, '');
            console.log("At least one radio button checked for:", cleanedIdPrefix);
            if (sessionData.hasOwnProperty(cleanedIdPrefix)) {
                delete sessionData[cleanedIdPrefix]; // Delete the specific key for the radio group
                sessionStorage.setItem('AlertStore', JSON.stringify(sessionData));
                console.log("Radio button check passed for:", cleanedIdPrefix);
            } else {
                console.log("No matching entry in sessionData for:", cleanedIdPrefix);
            }
            console.log("TestSession remove radio", sessionData);
        }
    }
}

function checkNullValuesTier2Dropdown(id){
    var dropdown = document.getElementById(id);
    if (dropdown){
        console.log(dropdown.getAttribute('id'));
        // Check if the dropdown value is unselected (assuming the default unselected value is "")
        if (dropdown.value === "") {
            isFormValid = false;
    
            var questionText = dropdown.closest('tr').querySelector('th') ? dropdown.closest('tr').querySelector('th').textContent.trim() : "Question";
            var sessionData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};
            console.log('Session data after initialze',sessionData)
            sessionData[id] = questionText;
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionData));   
            console.log("TestSession before",sessionData)
            // Show alert with the question text
            //alert("Please select a value from the dropdown for the question: " + questionText);
    
            // Stop further execution of the event handler once the alert is shown
            // Exit the loop to ensure no further alerts
        }
        else{
            var sessionData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};
            delete sessionData[id];
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionData));
            console.log("TestSession remove",sessionData)
        }
    }
    
}
function checkNullValuesTier2Checkbox(idPrefix) {
    var checkboxes = document.querySelectorAll("input[type='checkbox'][id^='" + idPrefix + "']");
    var isChecked = false;
    if (checkboxes.length > 0){
        checkboxes.forEach(function(checkbox) {
            if (checkbox.checked) {
                isChecked = true; // If any checkbox is checked, set this to true
            }
        });
        //console.log("Checkboxes group", checkboxes);
    
        var sessionData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};
    
        if (!isChecked) {
            isFormValid = false;
        
            var questionText = checkboxes[0].closest('tr').querySelector('th') ? checkboxes[0].closest('tr').querySelector('th').textContent.trim() : "Question";
    
            sessionData[idPrefix] = questionText;
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionData));
            console.log("Checkbox check failed for:", idPrefix, sessionData);
        } else {
            console.log("TestSession before remove checkbox:", sessionData);
            
            var cleanedIdPrefix = idPrefix.replace(/_AO\d+_checkbox$/, '');
            console.log("At least one checkbox checked for:", cleanedIdPrefix);
            //if (sessionData.hasOwnProperty(cleanedIdPrefix)) {
            if (cleanedIdPrefix in sessionData) {
                delete sessionData[idPrefix]; // Delete the specific key for the checkbox group
                delete sessionData[cleanedIdPrefix]; // Delete the specific key for the checkbox group
                sessionStorage.setItem('AlertStore', JSON.stringify(sessionData));
                console.log("Checkbox check passed for:", cleanedIdPrefix);
            } else {
                console.log("No matching entry in sessionData for:", cleanedIdPrefix);
            }
            console.log("TestSession remove checkbox", sessionData);
        }
            
        }
}

function clearAlertsSessionDataWhenUnchecked(id){
    var sessionAlData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};
    var sessionLSData = JSON.parse(sessionStorage.getItem('LSStore')) || {};

    console.log('clearAlertsSessionDataWhenUnchecked sessionLSData', sessionLSData, 'sessionAlData', sessionAlData)
    
    if (id.endsWith('_radio') || id.endsWith('_checkbox')) {
        if (sessionAlData.hasOwnProperty(id)) {
            delete sessionAlData[id]; // Delete the specific key for the checkbox group
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionAlData));
            console.log("clear Alert Session Data for :", sessionAlData);
        }
        var idPrefix = id.split('_AO')[0];
        if (idPrefix in sessionAlData) {
        //if (sessionAlData.hasOwnProperty(idPrefix)) {
            delete sessionAlData[idPrefix]; // Delete the specific key for the checkbox group
            delete sessionAlData[id]; // Delete the specific key for the checkbox group
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionAlData));
            console.log("clear Alert Session Data for :", sessionAlData);
        }
    } else{
        if (sessionAlData.hasOwnProperty(id)) {
            delete sessionAlData[id]; // Delete the specific key for the checkbox group
            sessionStorage.setItem('AlertStore', JSON.stringify(sessionAlData));
            console.log("clear Alert Session Data for :", sessionAlData);
        }
    }
}

function clearSessionDataWhenUnchecked(childID,questionCode){
    var sessionAlData = JSON.parse(sessionStorage.getItem('AlertStore')) || {};
    var sessionLSData = JSON.parse(sessionStorage.getItem('LSStore')) || {};

    //console.log('clearSessionDataWhenUnchecked ', childID, '-', questionCode,  ' sessionLSData :', sessionLSData, 'sessionAlData: ', sessionAlData);

    var ids = $('#' + childID + questionCode).find('*').map(function() {
        return this.id ? this.id : null; // Return the ID or null if it doesn't exist
    }).get().filter(Boolean); // Remove null values
    //console.log('clearSessionDataWhenUnchecked ids', sessionLSData, childID, questionCode);            
    // Check if any ID is in sessionData
    ids.forEach(function(id) {
        if (id.endsWith('_radio') || id.endsWith('_checkbox')) {
            if (sessionAlData.hasOwnProperty(id)) {
                delete sessionAlData[id]; // Delete the specific key for the checkbox group
                sessionStorage.setItem('AlertStore', JSON.stringify(sessionAlData));
                console.log("clear Alert Session Data for :", sessionAlData);
            }
            if (id.split('_AO').length > 0) {
            var idPrefix = id.split('_AO')[0];
            if (sessionAlData.hasOwnProperty(idPrefix)) {
                delete sessionAlData[idPrefix]; // Delete the specific key for the checkbox group
                sessionStorage.setItem('AlertStore', JSON.stringify(sessionAlData));
                console.log("clear Alert Session Data for :", sessionAlData);
            }
            }
        } else{
            if (sessionAlData.hasOwnProperty(id)) {
                delete sessionAlData[id]; // Delete the specific key for the checkbox group
                sessionStorage.setItem('AlertStore', JSON.stringify(sessionAlData));
                console.log("clear Alert Session Data for :", sessionAlData);
            }
        }
        if (sessionLSData.hasOwnProperty(id)) {
            var element = $('#' + id);
            element.closest('.answer-item').find('input:hidden').val('N/A');
            if (element.is(':checkbox') || element.is(':radio')) {
                element.prop('checked', false); // Uncheck the checkbox or radio button
                element.val(''); // Reset the hidden input value
                delete sessionLSData[id]; // Delete the specific key for the checkbox group
            } else if (element.is('select')) {
                element.prop('selectedIndex', 0); // Reset the select input to its first option
                element.val(''); // Reset the hidden input value
                delete sessionLSData[id]; // Delete the specific key for the checkbox group
            } else {
                element.val(' '); // Reset the hidden input value
                delete sessionLSData[id]; // Delete the specific key for the checkbox group                
            }
            sessionStorage.setItem('LSStore', JSON.stringify(sessionLSData));
            console.log("clear LS Session Data for :", sessionLSData);
        }      
        //console.log("TestSession remove checkbox clearSession", id);
        
    });
}



function conditionalCheckBoxAllQuestion(questionID, parentID, childID) {
    
    
    let thisQuestion = $('#question'+questionID);

    //console.log(thisQuestion, parentID, childID);
    
    // Hide all elements with IDs that start with a specific pattern initially
    $('[id^=' + childID + 'SQ]').hide();
    
    $('tr[id^=' + childID + 'SQ]').on('change', 'input, select, textarea', function() {
        var id = $(this).attr('id');
        var name = $(this).attr('name');
        // if (name.endsWith('_radiogroup')) {
        //     id = name.split('_radiogroup')[0];
        // }
        var value = $(this).val();
        var tagName = $(this).prop('tagName').toLowerCase();
        var elementType = $(this).attr('type');
        
        var sqIndex = name.indexOf('SQ');
        var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
        console.log('child id changed : ', name, sqIndex, questionCode, $(this).val());
        
        var idPrefix = id.split('_AO')[0]; // This assumes the prefix before "_AO" is common for the group
        clearAlertsSessionDataWhenUnchecked(id);
        checkNullValuesTier2Dropdown(id);
        checkNullValuesTier2Checkbox(idPrefix);
        checkNullValuesTier2Radio(idPrefix);
        
        // Skip hidden elements
        if (!$(this).is(':visible')) {
            return;
        }
        
        if (tagName === 'input') {
            if (elementType === 'checkbox' || elementType === 'radio') {

                value = $(this).is(':checked');
                var checkboxValue = $(this).prop('checked') ? "1" : "0"; // Change value based on checkbox state
                $(this).closest('.answer-item').find('input:hidden').val(checkboxValue);  
                
                CheckforAnswerOneQuesonRadioCheckbox(questionID, questionCode);
            } 
            
            if (name.endsWith('_radiogroup')) {
                  if ($(this).prop('checked')) {
                    value = $(this).is(':checked');
                    var radioValue = $(this).val();
                    $(this).closest('.answer-item').find('input[type="hidden"]').val(radioValue);
                }
            }
        }
        
        console.log('Child Changed  Id:', name, ' ', id, ' value: ', value, 'tagName: ', tagName, 'elementType: ', elementType);
        saveAnswers($(this));
        /*
        // Save the changes to session storage
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        sessionData[id] = value;
        sessionStorage.setItem('LSStore', JSON.stringify(sessionData));
        */
    }); 
    
    // Add a change event listener to all input element whose id conatins parentID
    //$('input[id*="' + parentID + '"]').change(function() {
    $('input[name^="' + parentID + '"]').change(function() {

        $('[id^=' + childID + 'SQ]').hide();
        
        // Do something with each element
        //console.log('change', $(this).attr('name'), 'checked ', $(this).prop('checked'), 'value ', $(this).val());
        var name = $(this).attr('name');
        // Get the label associated with the element
        // Check if the label is disabled

        //var sqIndex = name.indexOf('SQ');
		//var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
        //console.log('conditional debug : ', questionCode, ' ', sqIndex, ' ', childID, ' ', $('#' + childID + questionCode).length);
        //resetAnswers(childID, questionCode, questionID);
        //clearSessionDataWhenUnchecked(childID,questionCode);

        /*
        var childElement = $('#' + childID + questionCode);
        
        // Toggle the visibility of the corresponding element based on the checkbox value
		if ($(this).prop('checked')) {
		    console.log('Unset default for ', childID)
		    
            childElement.find('input[type="hidden"]').each(function() {
                var id = $(this).attr('id');
                if (id && (!id.includes('_textbox') && !id.includes('_date'))) { 
                    saveAnswers($(this));
                    $(this).val(''); // Clear the value
                }            
                //$(this).val('');
                //var value = $(this).val();
                
            });
        
            //if (childElement.length) childElement.show();
            //$('#' + childID + questionCode).show();
		} else {
		    console.log('Set default for ', childID)
		    
            childElement.find('input[type="hidden"]').each(function() {
                //var id = $(this).attr('Name');
                $(this).val('N/A');
                //var value = $(this).val();
                
            });		    
		    
            //if (childElement.length) childElement.hide();
            //$('#' + childID + questionCode).hide();
		} */
		
		/*
        // Count the number of checked with checked
        var count = $('input[id*="' + parentID + '"]').filter(function() {
            if ($(this).prop('checked') === true) {
                console.log('parent name ', $(this).attr('name'));
                var sqIndex = $(this).attr('name').indexOf('SQ');
                // Ensure 'SQ' is found and not part of a larger substring
        		var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
                console.log('inside conditional debug : ', questionCode, ' ', sqIndex, ' ', childID, ' ', $('#' + childID + questionCode).length);
        		
                if ($('#' + childID + questionCode).length) {
                    return $(this);
                }
            }; // Checks if the checkbox is checked and valid child index
        }).length; // Counts the filtered checkboxes
        console.log('Child count', count); // Logs the count to the console
        */
    var count = 0;
    
    $('input[name^="' + parentID + '"]').each(function() {
        var sqIndex = $(this).attr('name').indexOf('SQ');
        var questionCode = sqIndex !== -1 ? $(this).attr('name').substring(sqIndex, sqIndex + 5) : null;
        if ($(this).prop('checked') === true) {
            console.log('parentID is true no clear SessionData', parentID, 'val ', $(this).prop('checked'), childID,questionCode);

            //console.log('parent name ', $(this).attr('name'));
            //var sqIndex = $(this).attr('name').indexOf('SQ');
            // Ensure 'SQ' is found and not part of a larger substring
            //var questionCode = sqIndex !== -1 ? $(this).attr('name').substring(sqIndex, sqIndex + 5) : null;
            //console.log('inside conditional debug : ', questionCode, ' ', sqIndex, ' ', childID, ' ', $('#' + childID + questionCode).length);

            if ($('#' + childID + questionCode).length) {
                count++;
                $('#' + childID + questionCode).show();
                var ids = $('#' + childID + questionCode).find('*').map(function() {
                    return this.id ? this.id : null; // Return the ID or null if it doesn't exist
                }).get().filter(Boolean); // Remove null values
                //console.log('Ids', ids); // Log the array of IDs to the console
                var checkSelids = $('#' + childID + questionCode).find('input[type=hidden]').map(function() {
                    return this.name ? this.name : null; // Return the ID or null if it doesn't exist
                }).get().filter(Boolean); // Remove null values
                console.log('checkSelids', checkSelids); // Log the array of IDs to the console
                //resetAnswers(ids);
                console.log('ids', ids)
                // Retrieve session data
                var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};

                // Check if any ID is in sessionData
                ids.forEach(function(id) {
                    var element = $("input[id='" + id + "']"); // Use jQuery to select the element
                    if (element.length === 0) { // Check if no elements were found
                        // If no elements are found, log a message and continue to the next iteration
                        console.log('No element found for ID:', id);
                        return; // This will skip the rest of the current iteration
                    }
                
                    if (sessionData.hasOwnProperty(id)) {
                        console.log('conditionalCheckBoxAllQuestion ID from sessionData found:', id, sessionData[id]);
                        //var element = $('#' + id);
                        //var element = document.querySelectorAll("input[id='" + id + "']");

                        var elementType = element.attr('type');
                        var tagName = element.prop('tagName').toLowerCase();
                        var value = sessionData[id];
                        console.log('conditionalCheckBoxAllQuestion elementType and tagName :', elementType, tagName, sessionData[id]);
            
                        // Check if the element is visible before setting its value
                        if (element.is(':visible')) {
                            if (tagName === 'input') {
                                if (elementType === 'checkbox' || elementType === 'radio') {
                                    element.prop('checked', value);
                                    console.log('Checkbox Checked State:', element.prop('checked'));
                                    var checkboxValue = element.prop('checked') ? "1" : "0"; // Change value based on checkbox state
                                    element.closest('.answer-item').find('input:hidden').val(checkboxValue);
                                    console.log('Checkbox Value Set to ', checkboxValue);
                                } else {
                                    element.val(value);
                                    element.closest('.answer-item').find('input:hidden').val(value);
                                }
                            } else if (tagName === 'select' || tagName === 'textarea') {
                                element.closest('.answer-item').find('input:hidden').val(value);
                                element.val(value);
                            }
                        }
                    } 
                });
                
                
                for (var i = 0; i < ids.length; i++) {
                    var id = ids[i];
                    if (id.startsWith('select_answer') && id.endsWith('_dropdown')) {
                        checkNullValuesTier2Dropdown(id);
                    }
                }   
                for (var i = 0; i < ids.length; i++) {
                    var id = ids[i];
                    if (id.startsWith('answer') && id.endsWith('_checkbox')) {
                        var idPrefix = id.split('_AO')[0]; // This assumes the prefix before "_AO" is common for the group
                        checkNullValuesTier2Checkbox(idPrefix);
                    }
                }

                for (var i = 0; i < ids.length; i++) {
                    var id = ids[i];
                    if (id && id.startsWith('answer') && id.endsWith('_radio')) {
                        var idPrefix = id.split('_AO')[0]; // This assumes the prefix before "_AO" is common for the group
                        if (idPrefix){
                            checkNullValuesTier2Radio(idPrefix);
                        }
                    }
                }
                
                var checkSelidsvals = $('#' + childID + questionCode).find('input[type=hidden]').map(function() {
                    return this.name ? { name: this.name, value: this.value } : null; // Return an object with name and value
                }).get().filter(Boolean); // Remove null values
                console.log('checkSelidsvals', checkSelidsvals); // Log the array of objects with name and value
            }
        } else {
            //console.log('parentID false clear Data ', parentID, 'val ', $(this).prop('checked'), childID,questionCode);
            clearSessionDataWhenUnchecked(childID,questionCode);
        }
    });
    console.log('Child count', count); // Logs the count to the console
    
    
        // Show thisQuestion if count is greater than 0
        if (count > 0) {
            thisQuestion.show();
        } else {
            thisQuestion.hide();
            //console.log("hide",thisQuestion)
        }
    
    });
    

    // Select all elements where the id contains "patrentID" add trigger for change
    $('input[name^="' + parentID + '"]').each(function() {
        // Do something with each element
        $(this).trigger('change');
        //console.log('added trigger', $(this).attr('id'));
    });

}
function conditionalCheckBoxAllQuestionNew(questionID, parentID, childID) {

    let thisQuestion = $('#question' + questionID);

    // Hide all elements with IDs that start with a specific pattern initially
    $('[id^=' + childID + 'SQ]').hide();
    
    // Set up change listeners on the child elements
    $('tr[id^=' + childID + 'SQ]').on('change', 'input, select, textarea', function() {
        var id = $(this).attr('id');
        var name = $(this).attr('name');
        var value = $(this).val();
        var tagName = $(this).prop('tagName').toLowerCase();
        var elementType = $(this).attr('type');

        var sqIndex = name.indexOf('SQ');
        var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
        
        // Skip hidden elements
        if (!$(this).is(':visible')) {
            return;
        }


        // Handle input elements like checkboxes or radio buttons
        if (tagName === 'input') {
            if (elementType === 'checkbox' || elementType === 'radio') {
                value = $(this).is(':checked');
                var checkboxValue = $(this).prop('checked') ? "1" : "0"; // Change value based on checkbox state
                $(this).closest('.answer-item').find('input:hidden').val(checkboxValue);  
                
                CheckforAnswerOneQuesonRadioCheckbox(questionID, questionCode);
            }
        }
        
        // Save the changes to session storage
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        sessionData[id] = value;
        sessionStorage.setItem('LSStore', JSON.stringify(sessionData));
    }); 
    
    // Add a change event listener to all input elements whose id contains parentID
    $('input[id*="' + parentID + '"]').change(function() {
        $('[id^=' + childID + 'SQ]').hide();

        var count = 0;
        $('input[id*="' + parentID + '"]').each(function() {
            if ($(this).prop('checked') === true) {
                var sqIndex = $(this).attr('name').indexOf('SQ');
                var questionCode = sqIndex !== -1 ? $(this).attr('name').substring(sqIndex, sqIndex + 5) : null;

                if ($('#' + childID + questionCode).length) {
                    count++;
                    $('#' + childID + questionCode).show();
                    var ids = $('#' + childID + questionCode).find('*').map(function() {
                        return this.id ? this.id : null; // Return the ID or null if it doesn't exist
                    }).get().filter(Boolean); // Remove null values

                    // Retrieve session data
                    var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};

                    // Check if any ID is in sessionData
                    ids.forEach(function(id) {
                        if (sessionData.hasOwnProperty(id)) {
                            var element = $('#' + id);
                            var elementType = element.attr('type');
                            var tagName = element.prop('tagName').toLowerCase();
                            var value = sessionData[id];
                
                            if (element.is(':visible')) {
                                if (tagName === 'input') {
                                    if (elementType === 'checkbox' || elementType === 'radio') {
                                        element.prop('checked', value);
                                        var checkboxValue = element.prop('checked') ? "1" : "0";
                                        element.closest('.answer-item').find('input:hidden').val(checkboxValue);
                                    } else {
                                        element.val(value);
                                        element.closest('.answer-item').find('input:hidden').val(value);
                                    }
                                } else if (tagName === 'select' || tagName === 'textarea') {
                                    element.closest('.answer-item').find('input:hidden').val(value);
                                    element.val(value);
                                }
                            }
                        }
                    });
                }
            }
        });

        // Show or hide the parent question based on the count of checked checkboxes
        if (count > 0) {
            thisQuestion.show();
        } else {
            thisQuestion.hide();
        }
    });
    
    // Automatically trigger change event for all parentID-related input elements
    $('input[id*="' + parentID + '"]').each(function() {
        $(this).trigger('change');
    });

}


function CheckforConditionChecked(parentID, childID, questionID){
    let thisQuestion = $('#question'+questionID);
    var count = 0;
    $('input[name^=' + parentID + ']').each(function() {
        //console.log('Parent Value and id', $(this).val(), $(this).attr('name'));
        var sqIndex = $(this).attr('name').indexOf('SQ');
        var questionCode = sqIndex !== -1 ? $(this).attr('name').substring(sqIndex, sqIndex + 5) : null;
        if ($(this).val() === '1') {
            //console.log('parent name ', $(this).attr('name'));
            //var sqIndex = $(this).attr('name').indexOf('SQ');
            // Ensure 'SQ' is found and not part of a larger substring
            //var questionCode = sqIndex !== -1 ? $(this).attr('name').substring(sqIndex, sqIndex + 5) : null;
            //console.log('inside conditional debug : ', questionCode, ' ', sqIndex, ' ', childID, ' ', $('#' + childID + questionCode).length);
                        
            if ($('#' + childID + questionCode).length) {
                count++;
                $('#' + childID + questionCode).show();
                var ids = $('#' + childID + questionCode).find('*').map(function() {
                    //console.log('ChildID Id', this.id);
                    return this.id ? this.id : null; // Return the ID or null if it doesn't exist
                }).get().filter(Boolean); // Remove null values
                console.log('Ids', ids); // Log the array of IDs to the console
                var checkSelids = $('#' + childID + questionCode).find('input[type=hidden]').map(function() {
                    return this.name ? this.name : null; // Return the ID or null if it doesn't exist
                }).get().filter(Boolean); // Remove null values
                console.log('checkSelids', checkSelids); // Log the array of IDs to the console
                //resetAnswers(ids);

                // Retrieve session data
                var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
                
                // Check if any ID is in sessionData
                ids.forEach(function(id) {
                    //var element = $('#' + id);
                    //var radios = document.querySelectorAll("input[type='radio'][id^='" + id + "']");
                    //var element = document.querySelectorAll("input[type='radio'][id^='" + id + "'], input[type='checkbox'][id^='" + id + "']");
                    //var element = document.querySelectorAll("input[id='" + id + "']");
                    var element = $("input[id^='" + id + "']"); // Use jQuery to select the element
                    if (element.length === 0) { // Check if no elements were found
                        // If no elements are found, log a message and continue to the next iteration
                        console.log('No element found for ID:', id);
                        return; // This will skip the rest of the current iteration
                    }
                    var elementType = element.attr('type');
                    var tagName = element.prop('tagName').toLowerCase();
                    
                    if (sessionData.hasOwnProperty(id)) {
                        console.log('CheckforConditionChecked ID from sessionData found:', id, sessionData[id]);
                        console.log('CheckforConditionChecked elementType and tagName :', elementType, tagName, sessionData[id]);
                        
                        var value = sessionData[id];
        
                        // Check if the element is visible before setting its value
                        if (element.is(':visible')) {
                            if (tagName === 'input') {
                                if (elementType === 'checkbox' || elementType === 'radio') {
                                    element.prop('checked', value);
                                    // Debugging information for checked state
                                    console.log('Checkbox Checked State:', element.prop('checked'));
                                    var checkboxValue = element.prop('checked') ? "1" : "0"; // Change value based on checkbox state
                                    //element.closest('.answer-item').find('input:text').val(checkboxValue);
                                    element.closest('.answer-item').find('input:hidden').val(checkboxValue);
                                    console.log('Checkbox Value Set to ', checkboxValue);
                                } else {
                                    element.val(value);
                                    element.closest('.answer-item').find('input:hidden').val(value);
                                }
                            } else if (tagName === 'select') {
                                console.log('Select Value ', value);
                                $(this).closest('.answer-item').find('input:hidden').val(value);
                                element.closest('div').find('select option').each(function(index) {
                                    console.log('elemt test', $(this).text(), ' ', value);
                                    if ($(this).text().toLowerCase() === value.toLowerCase()) {
                                        $(this).closest('select')[0].selectedIndex = index; // Set the index based on the text match
                                        console.log('Select Index Set to ', index, ' for value ', value);
                                        return false; // Break out of the loop
                                    }
                                });
                            } else if (tagName === 'textarea') {
                                element.closest('.answer-item').find('input:hidden').val(value);
                                console.log('Text Value ', value);
                                element.val(value);
                            }
                        }
                    }              
                }); 
                console.log(ids)
                for (var i = 0; i < ids.length; i++) {
                    var id = ids[i];
        
                    if (id && id.startsWith('select_answer') && id.endsWith('_dropdown')) {
                        
                        checkNullValuesTier2Dropdown(id);
                        
                    }
                }   
                for (var i = 0; i < ids.length; i++) {
                    var id = ids[i];
                    if (id && id.startsWith('answer') && id.endsWith('_checkbox')) {
                        var idPrefix = id.split('_AO')[0]; // This assumes the prefix before "_AO" is common for the group
                        if (idPrefix){
                            checkNullValuesTier2Checkbox(idPrefix);
                        }
                    }
                }
                for (var i = 0; i < ids.length; i++) {
                    var id = ids[i];
                    if (id && id.startsWith('answer') && id.endsWith('_radio')) {
                        var idPrefix = id.split('_AO')[0]; // This assumes the prefix before "_AO" is common for the group
                        if (idPrefix){
                            checkNullValuesTier2Radio(idPrefix);
                        }
                    }
                }
                var checkSelidsvals = $('#' + childID + questionCode).find('input[type=hidden]').map(function() {
                    return this.name ? { name: this.name, value: this.value } : null; // Return an object with name and value
                }).get().filter(Boolean); // Remove null values
                console.log('checkSelidsvals', checkSelidsvals); // Log the array of objects with name and value                

            }
        }else {
            clearSessionDataWhenUnchecked(childID,questionCode);
        }
    });
    console.log('Child count', count); // Logs the count to the console   
    
    // Show thisQuestion if count is greater than 0
    if (count > 0) {
        thisQuestion.show();
    } else {
        thisQuestion.hide();
    }
        
}

function CheckforAnswerOneQuesonRadioCheckbox(questionID, questionCode) {
    /*var checkboxInputs = $('input[name*="' + questionID + questionCode + '"]:checkbox, radio').each(function() {
        console.log('Checkbox input:', $(this).attr('id'), 'val:', $(this).prop('checked'));
    });*/
    var checkboxInputs = $('input[name*="' + questionID + questionCode + '"]:checkbox').each(function() {
        console.log('Input:', $(this).attr('id'), 'val:', $(this).prop('checked'));
    });
    


    // Get and log the IDs of the hidden inputs

    // Log or process the text inputs
    var anyCheckFlag = false;
    
    checkboxInputs.each(function() {
        console.log('Hidden input:', $(this).attr('id'), 'val : ', $(this).prop('checked'));
        if ($(this).prop('checked')) { // Check if the value is '1' as a string
            anyCheckFlag = true;
            console.log('Exit loop input:', $(this).attr('id'), 'val : ', $(this).prop('checked'));
            return false; // Break out of the loop
        }
    });
    
    if (anyCheckFlag) {
        checkboxInputs.each(function() {
            var checkboxValue = $(this).prop('checked') ? "1" : "0"; // Change value based on checkbox state
            //$(this).val(checkboxValue);
            var hiddenInputElement = $(this).closest('.answer-item').find('input:hidden');
            //var hiddenInputElement = $(this).closest('input[type="hidden"]');
            //var hiddenInputElement = $(this).find('input:hidden');
            hiddenInputElement.val(checkboxValue);
            console.log('partical or full check :',hiddenInputElement.length,  hiddenInputElement.attr('name'), 'val : ', hiddenInputElement.val());
        });
    } else {
        checkboxInputs.each(function() {
            var checkboxValue = $(this).prop('checked') ? "1" : "0"; // Change value based on checkbox state
            //$(this).val(checkboxValue);
            var hiddenInputElement = $(this).closest('.answer-item').find('input:hidden');
            hiddenInputElement.val('');
            console.log('No check :', hiddenInputElement.attr('name'), 'val : ', hiddenInputElement.val());
        });                    
    }    
    
}

function conditionalChecklistAllQuestion(questionID, parentID, childID) {
    let thisQuestion = $('#question'+questionID);

    // Hide all elements with IDs that start with a specific pattern initially
    $('[id^=' + childID + 'SQ]').hide();

    $('tr[id^=' + childID + 'SQ]').on('change', 'input, select, textarea', function() {
    //$('[id^=' + childID + 'SQ]').change(function() {
        var id = $(this).attr('id');
        var name = $(this).attr('name');
        var value = $(this).val();
        
        var tagName = $(this).prop('tagName').toLowerCase();
        var elementType = $(this).attr('type');
        var idPrefix = id.split('_AO')[0]; // This assumes the prefix before "_AO" is common for the group
        clearAlertsSessionDataWhenUnchecked(id);
        checkNullValuesTier2Dropdown(id);
        checkNullValuesTier2Checkbox(idPrefix);
        checkNullValuesTier2Radio(idPrefix);
        var sqIndex = name.indexOf('SQ');
        var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
        console.log('child id changed : ', name, sqIndex, questionCode, $(this).val());        

        // Skip hidden elements
        if (!$(this).is(':visible')) {
            return;
        }
        
        console.log('Child Changed name :', name, ' id: ', id, ' value: ', value , 'tagName: ', tagName, 'elementType: ', elementType);
    
        if (tagName === 'input') {
            if (elementType === 'checkbox' || elementType === 'radio') {
                value = $(this).is(':checked');
                var checkboxValue = $(this).prop('checked') ? "1" : "0"; // Change value based on checkbox state
                $(this).closest('.answer-item').find('input:hidden').val(checkboxValue);                
                CheckforAnswerOneQuesonRadioCheckbox(questionID, questionCode);
            }
        }
        saveAnswers($(this));

        /*
        // Save the changes to session storage
        var sessionData = JSON.parse(sessionStorage.getItem('LSStore')) || {};
        sessionData[id] = value;
        console.log('stored id', id, 'value ', value);
        sessionStorage.setItem('LSStore', JSON.stringify(sessionData));*/
        
    
    }); 
    
    // Add a change event listener to all textboxes whose name starts with a specific pattern
    $('input[name^=' + parentID + ']').change(function () {
        var name = $(this).attr('name');
        var sqIndex = name.indexOf('SQ');
        var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;
        //console.log('parent id changed : ', name, sqIndex, questionCode, $(this).val());
        // Toggle the visibility of the corresponding element based on the textbox value
        //var childElement = $('#' + childID + questionCode);
        //$('.answer-item', thisQuestion).find('input:hidden').val('');
        $('[id^=' + childID + 'SQ]').hide();
        //resetAnswers(childID, questionCode, questionID);
        //clearSessionDataWhenUnchecked(childID,questionCode);


        /*
        var textInputs = childElement.closest('tr').find('input'); // Assuming 'tr' is the row container
        
        var childAnswerItems = textInputs.map(function() {
            return this.name;
        }).get();  // Collect the IDs of all the answer items
        
        console.log('childAnswerItems', childAnswerItems);
        if ($(this).val() === '1') {
            textInputs.find('input').each(function() {
                var id = $(this).attr('id'); // Get the value of the 'id' attribute
                if (id && (!id.includes('_textbox') && !id.includes('_date'))) { 
                    console.log('Reset the value to null ')
                    saveAnswers($(this));
                    $(this).val(''); // Clear the value
                }
            });    		
        } else {
            //childElement.hide();
    		childElement.find('input:hidden').val('N/A');
        } */


        /*
        // Count the number of textboxes with value "1"
        var count = $('input[type=text][name^=' + parentID + ']').filter(function() {
            return $(this).val() === '1';
        }).length; */

        CheckforConditionChecked(parentID, childID, questionID);

    });
    
    //$('.answer-item', thisQuestion).find('input:hidden').val('');
    //CheckforConditionChecked(parentID, childID, thisQuestion);

    // Trigger the change event for each textbox to set the initial visibility
    $('input[type=text][name^=' + parentID + ']').trigger('change');
    /*
    // Select all elements where the id contains "patrentID" add trigger for change
    $('input[name*="' + parentID + '"]').each(function() {
        // Do something with each element
        $(this).trigger('change');
        //console.log('added trigger', $(this).attr('id'));
    });*/
}

function conditionalCheckboxTableQuestion(questionID, parentID, childID) {

	// Hide all elements with IDs that start with a specific pattern initially
	$('[id^=' + childID + 'SQ]').hide();

	// Add a change event listener to all checkboxes whose name starts with a specific pattern
	$('input[type=checkbox][name^=' + parentID + ']').change(function () {
		var name = $(this).attr('name');
		var sqIndex = name.indexOf('SQ');
		var questionCode = sqIndex !== -1 ? name.substring(sqIndex, sqIndex + 5) : null;

		// Toggle the visibility of the corresponding element based on the checkbox state
		if ($(this).prop('checked')) {
			$('#' + childID + questionCode).show();
		} else {
			$('#' + childID + questionCode).hide();
		}
	});

	// Add a change event listener to only the last checkbox whose name starts with "321122X3X8887"
	$('input[type=checkbox][name^=' + parentID + ']:last').change(function () {
		if ($(this).prop('checked')) {
			$('[id^=' + childID + ']').hide();
		}
		$('#question'+questionID).addClass('ls-hidden');
	});

	// Trigger the change event for each checkbox to set the initial visibility
	$('input[type=checkbox][name^=' + parentID + ']').trigger('change');
}

function heightConverter(feetInputId, inchesInputId, cmInputId) {
    // Function to convert height from feet and inches to centimeters
    function feetAndInchesToCm(feet, inches) {
        var totalInches = parseInt(feet) * 12 + parseInt(inches);
        var cm = totalInches * 2.54;
        return Math.round(cm);
    }

    // Function to convert height from centimeters to feet and inches
    function cmToFeetAndInches(cm) {
        var inches = cm / 2.54;
        var feet = Math.floor(inches / 12);
        inches = Math.round(inches % 12);
        if (inches === 12) {
            feet++;  // Increase feet by 1
            inches = 0;  // Reset inches to 0
        }
        return { feet: feet, inches: inches };
    }

    // Function to update the other input field based on user input
    function updateHeightInput(inputType) {
        if (inputType === 'feetAndInches') {
            var feetInput = document.getElementById(feetInputId);
            var inchesInput = document.getElementById(inchesInputId);
            
            var feet = parseInt(feetInput.value) || 0;
            var inches = parseInt(inchesInput.value) || 0;
            
            // Reset border colors
            feetInput.style.borderColor = '';
            inchesInput.style.borderColor = '';
            
            // If feet is empty and inches are within range, set feet to 0
            if (inches > 11 && inches <= 119) {
                feet = 0;
                feetInput.value = 0;
                var inchesToCm = feetAndInchesToCm(feet, inches);
                document.getElementById(cmInputId).value = inchesToCm;
            }
            else if (inches === 11 && feet === 0){
                // Valid case
            }
            // If inches are within range and feet is not empty, ensure feet is less than or equal to 9
            else if (feet > 0 && inches >= 0 && inches <= 11 && feet <= 9) {
                // Valid case
            }
            else {
                document.getElementById(cmInputId).value = '';
                feetInput.style.borderColor = 'red';
                inchesInput.style.borderColor = 'red';
                return;
            }
            var cm = feetAndInchesToCm(feet, inches);
            if (cm < 28 || cm > 303) {
                document.getElementById(cmInputId).style.borderColor = 'red';
                return;
            }
            document.getElementById(cmInputId).style.borderColor = '';
            document.getElementById(cmInputId).value = cm;
        } else if (inputType === 'centimeters') {
            var cmInput = document.getElementById(cmInputId);
            var cm = parseInt(cmInput.value) || 0;
            if (cm < 28 || cm > 303) {
                document.getElementById(feetInputId).value = '';
                document.getElementById(inchesInputId).value = '';
                cmInput.style.borderColor = 'red';
                return;
            }
            cmInput.style.borderColor = '';
            var height = cmToFeetAndInches(cm);
            document.getElementById(feetInputId).value = height.feet;
            document.getElementById(inchesInputId).value = height.inches;
        }
    }

    // Add event listeners to input fields
    document.getElementById(feetInputId).addEventListener('input', function() {
        updateHeightInput('feetAndInches');
    });

    document.getElementById(inchesInputId).addEventListener('input', function() {
        updateHeightInput('feetAndInches');
    });

    document.getElementById(cmInputId).addEventListener('input', function() {
        updateHeightInput('centimeters');
    });

    // Get the Next button element
    var nextButton = document.getElementById('ls-button-submit');

    // Check if nextButton exists before adding event listener
    if (nextButton) {
        // Add event listener for button click
        nextButton.addEventListener('click', function(event) {
            var inchesInput = document.getElementById(inchesInputId);
            var inchesValue = parseInt(inchesInput.value);
            if (isNaN(inchesValue)) {
                alert("Please enter the inches before proceeding.");
                window.location.hash = '#:~:text=Inches%20(valid%20values%200%20%2D%20119)';
                event.preventDefault(); // Prevent the default action (submitting the form)
            }
        });
    } else {
        console.error("Next button element not found in the DOM");
    }

    // Setting default values and constraints
    //document.getElementById(feetInputId).value = '';
    //document.getElementById(inchesInputId).value = '';
    document.getElementById(inchesInputId).setAttribute('min', 0);
    document.getElementById(inchesInputId).setAttribute('max', 119);
    document.getElementById(feetInputId).setAttribute('max', 9);
}



function weightConverter(poundsInputId, ouncesInputId, kgInputId) {
    function poundsAndOuncesToKg(pounds, ounces) {
        var totalOunces = parseInt(pounds) * 16 + parseInt(ounces);
        var kg = totalOunces * 0.0283495;
        return Math.round(kg);
    }

    function kgToPoundsAndOunces(kg) {
        var ounces = kg / 0.0283495;
        var pounds = Math.floor(ounces / 16);
        ounces = Math.round(ounces % 16);
        return { pounds: pounds, ounces: ounces };
    }

    function updateWeightInput(inputType) {
        if (inputType === 'poundsAndOunces') {
            var poundsInput = document.getElementById(poundsInputId);
            var ouncesInput = document.getElementById(ouncesInputId);
            
            var pounds = parseInt(poundsInput.value) || 0;
            var ounces = parseInt(ouncesInput.value) || 0;
            
            if (pounds < 5 || pounds > 1000 || ounces < 0 || ounces >= 16) {
                poundsInput.style.borderColor = 'red';
                ouncesInput.style.borderColor = 'red';
                document.getElementById(kgInputId).value = '';
                return;
            } else {
                poundsInput.style.borderColor = '';
                ouncesInput.style.borderColor = '';
            }

            var kg = poundsAndOuncesToKg(pounds, ounces);
            if (kg < 2 || kg > 454) {
                document.getElementById(kgInputId).style.borderColor = 'red';
                return;
            }
            document.getElementById(kgInputId).style.borderColor = '';
            document.getElementById(kgInputId).value = kg;
        } else if (inputType === 'kilograms') {
            var kgInput = document.getElementById(kgInputId);
            
            var kg = parseFloat(kgInput.value) || 0;
            
            if (kg < 2 || kg > 454) {
                kgInput.style.borderColor = 'red';
                document.getElementById(poundsInputId).value = '';
                document.getElementById(ouncesInputId).value = '';
                return;
            } else {
                kgInput.style.borderColor = '';
            }
            
            var weight = kgToPoundsAndOunces(kg);
            document.getElementById(poundsInputId).value = weight.pounds;
            document.getElementById(ouncesInputId).value = weight.ounces;
        }
    }

    document.getElementById(poundsInputId).addEventListener('input', function() {
        updateWeightInput('poundsAndOunces');
    });

    document.getElementById(ouncesInputId).addEventListener('input', function() {
        updateWeightInput('poundsAndOunces');
    });

    document.getElementById(kgInputId).addEventListener('input', function() {
        updateWeightInput('kilograms');
    });

    var nextButtonForOunces = document.getElementById('ls-button-submit');

    if (nextButtonForOunces) {
        nextButtonForOunces.addEventListener('click', function(event) {
            var ouncesInput = document.getElementById(ouncesInputId);
            if (ouncesInput) {
                var ouncesValue = parseInt(ouncesInput.value);
                if (isNaN(ouncesValue)) {
                    alert("Please enter the ounces before proceeding.");
                    event.preventDefault();
                }
            } else {
                console.error("Ounces input element not found in the DOM");
            }
        });
    } else {
        console.error("Next button for ounces element not found in the DOM");
    }

    //document.getElementById(poundsInputId).value = '';
    //document.getElementById(ouncesInputId).value = '';
    document.getElementById(poundsInputId).setAttribute('min', 5);
    document.getElementById(poundsInputId).setAttribute('max', 1000);
    document.getElementById(ouncesInputId).setAttribute('min', 0);
    document.getElementById(ouncesInputId).setAttribute('max', 15);
}









$(document).on('ready pjax:scriptcomplete',function(){
    /**
     * Code included inside this will only run once the page Document Object Model (DOM) is ready for JavaScript code to execute
     * @see https://learn.jquery.com/using-jquery-core/document-ready/
     */
});
$(document).ready(function() {
    $(".list-group-item.index-item.index-item-seen.index-item-unanswered.index-item-current").on('click', function() {
        // Removing active class from all items to ensure only the clicked one is green
        $(".list-group-item").removeClass("active");
        
        // Adding active class to the clicked item
        $(this).addClass("active");
    });
    
    
    /* Separate survey section h4 headers from question text */
    // Select all '.question-title-container' elements
    const questionTitleContainers = document.querySelectorAll('.question-title-container');

    // Iterate over each '.question-title-container'
    questionTitleContainers.forEach(container => {
        // Check if the container contains an 'h4' element
        if (container.querySelector('h4')) {
            // Add the 'contains-header' class to the container
            container.classList.add('contains-header');
        }
    });

});

