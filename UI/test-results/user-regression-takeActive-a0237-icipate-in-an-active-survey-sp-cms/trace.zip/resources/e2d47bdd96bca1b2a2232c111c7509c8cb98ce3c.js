/**
 * no-js/js class by external file : see https://bugs.limesurvey.org/view.php?id=11945
 */
(function (H) {
    H.className = H.className.replace(/\bno-js\b/, 'js');
})(document.documentElement);
